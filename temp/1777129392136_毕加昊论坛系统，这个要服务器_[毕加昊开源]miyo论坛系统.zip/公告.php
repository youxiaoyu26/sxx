<?php ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>通知公告 - 孝泉师范学校学生社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
        }
    </style>
    <style>
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #333;
            --text-secondary: #666;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow-color: rgba(90, 24, 154, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #e0e0e0;
            --text-secondary: #aaa;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --glass-bg: rgba(30, 30, 60, 0.85);
            --glass-border: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --card-bg: rgba(30, 30, 60, 0.6);
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #2e7d32;
            --text-secondary: #558b2f;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.4);
            --shadow-color: rgba(46, 125, 50, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        * {
            -webkit-tap-highlight-color: transparent;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif;
        }
        html, body {
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            background-attachment: fixed;
            color: var(--text-primary);
        }
        .glass {
            background: var(--glass-bg);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 16px;
            border: 1px solid var(--glass-border);
            box-shadow: 0 8px 32px var(--shadow-color);
        }
        .full-page-container {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .top-nav {
            width: 100%;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px) saturate(180%);
            border-bottom: 1px solid var(--glass-border);
            flex-shrink: 0;
        }
        .back-btn {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            background: var(--accent-light);
            border: none;
            color: var(--accent);
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        .back-btn:hover {
            background: var(--accent);
            color: white;
        }
        .nav-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        .nav-placeholder { width: 38px; }
        .main-content {
            flex: 1;
            width: 100%;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .announcement-card {
            padding: 18px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .announcement-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px var(--shadow-color);
        }
        .announcement-card.pinned {
            border-left: 4px solid var(--accent);
        }
        .card-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .pin-badge {
            background: var(--accent);
            color: white;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .card-title {
            font-size: 1.15rem;
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
        }
        .card-content {
            font-size: 0.95rem;
            color: var(--text-secondary);
            line-height: 1.6;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            margin-bottom: 12px;
        }
        .card-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }
        .card-author {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .load-more-btn {
            display: block;
            width: 200px;
            margin: 10px auto;
            padding: 12px 20px;
            background: var(--accent-light);
            color: var(--accent);
            border: 1px solid var(--accent);
            border-radius: 30px;
            font-size: 0.95rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .load-more-btn:hover {
            background: var(--accent);
            color: white;
        }
        .load-more-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        .loading-state {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
        .no-more {
            text-align: center;
            padding: 20px;
            color: var(--text-secondary);
            font-size: 0.85rem;
        }
        .detail-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.45);
            backdrop-filter: blur(6px);
            z-index: 2000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .detail-modal.show { display: flex; }
        .detail-content {
            width: 100%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            padding: 30px;
            animation: slideUp 0.3s ease;
        }
        .detail-close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--glass-bg);
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
            color: var(--text-primary);
            transition: all 0.2s ease;
        }
        .detail-close-btn:hover {
            background: var(--accent);
            color: white;
        }
        .detail-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 15px;
        }
        .detail-meta {
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--glass-border);
        }
        .detail-body {
            font-size: 1rem;
            line-height: 1.8;
            color: var(--text-primary);
            white-space: pre-wrap;
            word-break: break-word;
        }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        @media (max-width: 768px) {
            .top-nav { height: 55px; padding: 0 15px; }
            .back-btn { width: 34px; height: 34px; font-size: 16px; }
            .nav-placeholder { width: 34px; }
            .main-content { padding: 15px; }
            .announcement-card { padding: 15px; }
            .card-title { font-size: 1.05rem; }
            .detail-content { padding: 20px; }
            .detail-title { font-size: 1.2rem; }
        }
    </style>
</head>
<body>
    <div class="full-page-container">
        <nav class="top-nav">
            <button class="back-btn" id="backBtn"><i class="fas fa-arrow-left"></i></button>
            <div class="nav-title">通知公告</div>
            <div class="nav-placeholder"></div>
        </nav>
        <main class="main-content" id="announcementList">
            <div class="loading-state"><i class="fas fa-spinner fa-spin"></i> 正在加载公告...</div>
        </main>
    </div>
    <div class="detail-modal" id="detailModal">
        <div class="detail-content glass" style="position:relative;">
            <button class="detail-close-btn" id="detailCloseBtn"><i class="fas fa-times"></i></button>
            <div class="detail-title" id="detailTitle"></div>
            <div class="detail-meta" id="detailMeta"></div>
            <div class="detail-body" id="detailBody"></div>
        </div>
    </div>
    <script>
        let currentPage = 1;
        let hasMore = true;
        let isLoading = false;
        function formatTime(ts) {
            return new Date(ts * 1000).toLocaleString('zh-CN');
        }
        function loadAnnouncements(page, append) {
            if (isLoading) return;
            isLoading = true;
            fetch(`api.php?action=announcement_list&page=${page}&pageSize=10&active_only=1`)
                .then(r => r.json())
                .then(data => {
                    if (!data.success) {
                        document.getElementById('announcementList').innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><p>加载失败</p></div>';
                        return;
                    }
                    const { list, pagination } = data;
                    hasMore = pagination.has_more;
                    const container = document.getElementById('announcementList');
                    if (!append) container.innerHTML = '';
                    if (list.length === 0 && page === 1) {
                        container.innerHTML = '<div class="empty-state"><i class="fas fa-bullhorn"></i><p>暂无公告</p></div>';
                        return;
                    }
                    list.forEach(ann => {
                        const card = document.createElement('div');
                        card.className = 'announcement-card glass' + (ann.is_pinned ? ' pinned' : '');
                        card.innerHTML = `
                            <div class="card-header">
                                ${ann.is_pinned ? '<span class="pin-badge"><i class="fas fa-thumbtack"></i> 置顶</span>' : ''}
                                <div class="card-title">${ann.title}</div>
                            </div>
                            <div class="card-content">${ann.content}</div>
                            <div class="card-footer">
                                <span class="card-author"><i class="fas fa-user-shield"></i> ${ann.author}</span>
                                <span><i class="far fa-clock"></i> ${formatTime(ann.created_at)}</span>
                            </div>`;
                        card.addEventListener('click', () => showDetail(ann));
                        container.appendChild(card);
                    });
                    const oldBtn = document.getElementById('loadMoreBtn');
                    if (oldBtn) oldBtn.remove();
                    if (hasMore) {
                        const btn = document.createElement('button');
                        btn.id = 'loadMoreBtn';
                        btn.className = 'load-more-btn';
                        btn.textContent = '加载更多';
                        btn.addEventListener('click', () => {
                            currentPage++;
                            loadAnnouncements(currentPage, true);
                        });
                        container.appendChild(btn);
                    } else if (list.length > 0) {
                        const tip = document.createElement('div');
                        tip.className = 'no-more';
                        tip.textContent = '没有更多公告了';
                        container.appendChild(tip);
                    }
                })
                .catch(() => {
                    document.getElementById('announcementList').innerHTML = '<div class="empty-state"><i class="fas fa-wifi"></i><p>网络异常</p></div>';
                })
                .finally(() => { isLoading = false; });
        }
        function showDetail(ann) {
            document.getElementById('detailTitle').textContent = ann.title;
            document.getElementById('detailMeta').innerHTML = `
                <span><i class="fas fa-user-shield"></i> ${ann.author}</span>
                <span><i class="far fa-clock"></i> ${formatTime(ann.created_at)}</span>
                ${ann.expire_at ? '<span><i class="far fa-hourglass"></i> 有效期至 ' + formatTime(ann.expire_at) + '</span>' : ''}`;
            document.getElementById('detailBody').textContent = ann.content;
            document.getElementById('detailModal').classList.add('show');
        }
        document.getElementById('backBtn').addEventListener('click', () => { window.location.href = 'index.php'; });
        document.getElementById('detailCloseBtn').addEventListener('click', () => { document.getElementById('detailModal').classList.remove('show'); });
        document.getElementById('detailModal').addEventListener('click', (e) => {
            if (e.target.id === 'detailModal') document.getElementById('detailModal').classList.remove('show');
        });
        document.addEventListener('DOMContentLoaded', () => { loadAnnouncements(1, false); });
    </script>
</body>
</html>
