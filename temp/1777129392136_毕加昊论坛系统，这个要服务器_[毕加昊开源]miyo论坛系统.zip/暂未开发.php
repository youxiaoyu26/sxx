<?php
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; font-src 'self' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; img-src 'self' data:;");
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>功能暂未开发</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
        }
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #333;
            --text-secondary: #666;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --accent-gradient: linear-gradient(135deg, var(--accent), #7b2cbf);
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #e0e0e0;
            --text-secondary: #aaa;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --accent-gradient: linear-gradient(135deg, var(--accent), #9966ff);
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #2e7d32;
            --text-secondary: #558b2f;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --accent-gradient: linear-gradient(135deg, var(--accent), #66bb6a);
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif;
            border: none !important;
            outline: none !important;
        }
        html, body {
            width: 100vw !important;
            height: 100vh !important;
            max-width: 100vw !important;
            max-height: 100vh !important;
            overflow: hidden !important;
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            bottom: 0 !important;
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            background-attachment: fixed;
            color: var(--text-primary);
        }
        .container {
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 24px;
            padding: 0;
            margin: 0;
            animation: fadeInUp 0.6s ease forwards;
            opacity: 0;
        }
        .icon-box {
            width: 100px;
            height: 100px;
            border-radius: 0;
            background: var(--accent-light);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: breathe 2s ease-in-out infinite;
        }
        .icon {
            font-size: 48px;
            color: var(--accent);
        }
        .title {
            font-size: 24px;
            color: var(--text-primary);
            font-weight: 600;
            text-align: center;
        }
        .desc {
            font-size: 15px;
            color: var(--text-secondary);
            text-align: center;
            line-height: 1.6;
            max-width: 280px;
        }
        .back-btn {
            margin-top: 10px;
            padding: 14px 40px;
            background: var(--accent-gradient);
            color: #fff;
            border-radius: 0;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .back-btn:hover {
            transform: translateY(-3px);
            opacity: 0.9;
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @keyframes breathe {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }
        @media (max-width: 768px) {
            .icon-box {
                width: 90px;
                height: 90px;
            }
            .icon {
                font-size: 42px;
            }
            .title {
                font-size: 22px;
            }
            .desc {
                font-size: 14px;
            }
            .back-btn {
                padding: 12px 35px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon-box">
            <i class="fas fa-tools icon"></i>
        </div>
        <h1 class="title">功能暂未开发</h1>
        <p class="desc">该功能正在紧急开发中，敬请期待～</p>
        <button class="back-btn" onclick="history.back()">返回上一页</button>
    </div>
    <script>
        (function initTheme() {
            try {
                const savedTheme = localStorage.getItem('community_theme');
                if (savedTheme) {
                    const themeData = JSON.parse(savedTheme);
                    if (themeData.name === 'custom' && themeData.vars) {
                        Object.entries(themeData.vars).forEach(([key, value]) => {
                            document.documentElement.style.setProperty(key, value);
                        });
                    } 
                    else if (themeData.name && themeData.name !== 'light') {
                        document.documentElement.setAttribute('data-theme', themeData.name);
                    } else {
                        document.documentElement.removeAttribute('data-theme');
                    }
                }
            } catch (e) {
                document.documentElement.removeAttribute('data-theme');
            }
        })();
        (function lockScroll() {
            document.addEventListener('touchmove', function(e) {
                e.preventDefault();
            }, { passive: false, capture: true });
            document.addEventListener('wheel', function(e) {
                e.preventDefault();
            }, { passive: false, capture: true });
            document.addEventListener('keydown', function(e) {
                const forbiddenKeys = ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' '];
                if (forbiddenKeys.includes(e.key)) e.preventDefault();
            }, { capture: true });
        })();
    </script>
</body>
</html>
