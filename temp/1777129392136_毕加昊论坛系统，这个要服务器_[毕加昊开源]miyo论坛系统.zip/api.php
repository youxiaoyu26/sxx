<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(200);
}
$dataFile = 'data/posts.txt';
$passFile = 'data/password.txt';
$imageDir = 'data/images/';
$commentFile = 'data/comments.txt';
$likeFile = 'data/likes.txt';
$announcementFile = 'data/announcements.txt';
$logFile = 'data/admin_log.txt';
$hideAnnounceFile = 'data/hide_announce.txt';

if (!is_dir('data')) mkdir('data', 0755, true);
if (!is_dir($imageDir)) mkdir($imageDir, 0755, true);
foreach ([$dataFile, $commentFile, $likeFile, $announcementFile, $logFile, $hideAnnounceFile] as $f) {
    if (!file_exists($f)) file_put_contents($f, '');
}
if (!file_exists($passFile)) file_put_contents($passFile, 'admin123');
$action = $_GET['action'] ?? '';

function safeWrite($file, $content) {
    $fp = fopen($file, 'c');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    fwrite($fp, $content);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

function readLines($file) {
    if (!file_exists($file) || filesize($file) === 0) return [];
    return file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
}

function writeLines($file, $lines) {
    $content = empty($lines) ? '' : implode(PHP_EOL, $lines) . PHP_EOL;
    return safeWrite($file, $content);
}

function appendLine($file, $line) {
    $fp = fopen($file, 'a');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    fwrite($fp, $line . PHP_EOL);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

function writeLog($action, $detail = '') {
    global $logFile;
    $log = [
        'time' => date('Y-m-d H:i:s'),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'action' => $action,
        'detail' => $detail
    ];
    appendLine($logFile, json_encode($log, JSON_UNESCAPED_UNICODE));
}

function todayStr() {
    return date('Y-m-d');
}

function checkHideAnnounce() {
    global $hideAnnounceFile;
    $userIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if ($userIp === 'unknown') return false;
    $now = time();
    $lines = readLines($hideAnnounceFile);
    $newLines = [];
    $isHidden = false;
    foreach ($lines as $line) {
        $item = json_decode($line, true);
        if (!$item) continue;
        if ($item['expire_at'] <= $now) continue;
        if ($item['ip'] === $userIp) {
            $isHidden = true;
        }
        $newLines[] = $line;
    }
    writeLines($hideAnnounceFile, $newLines);
    return $isHidden;
}

function setHideAnnounce() {
    global $hideAnnounceFile;
    $userIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if ($userIp === 'unknown') return ['success' => false, 'message' => '无法获取用户IP'];
    $now = time();
    $expireAt = $now + 86400;
    $lines = readLines($hideAnnounceFile);
    $newLines = [];
    foreach ($lines as $line) {
        $item = json_decode($line, true);
        if (!$item || $item['ip'] === $userIp) continue;
        $newLines[] = $line;
    }
    $newItem = [
        'ip' => $userIp,
        'expire_at' => $expireAt,
        'created_at' => $now
    ];
    $newLines[] = json_encode($newItem, JSON_UNESCAPED_UNICODE);
    writeLines($hideAnnounceFile, $newLines);
    return ['success' => true, 'message' => '已设置24小时内不再显示'];
}

function uploadImage($file) {
    global $imageDir;
    $allowType = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 2 * 1024 * 1024;
    if ($file['error'] !== UPLOAD_ERR_OK) return ['success' => false, 'message' => '图片上传失败'];
    if (!in_array($file['type'], $allowType)) return ['success' => false, 'message' => '仅支持jpg/png/gif/webp格式的图片'];
    if ($file['size'] > $maxSize) return ['success' => false, 'message' => '图片大小不能超过2MB'];
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = uniqid() . '.' . $ext;
    $targetPath = $imageDir . $fileName;
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'path' => $targetPath];
    }
    return ['success' => false, 'message' => '图片保存失败，请检查目录权限'];
}

function getPostDetail($postId) {
    global $dataFile;
    if (empty($postId) || !file_exists($dataFile) || filesize($dataFile) === 0) {
        return ['success' => false, 'message' => '帖子不存在'];
    }
    $lines = readLines($dataFile);
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && $post['id'] === $postId) {
            if (!isset($post['category'])) $post['category'] = '普通';
            if (!isset($post['view_count'])) $post['view_count'] = 0;
            if (!isset($post['image'])) $post['image'] = '';
            if (!isset($post['like_count'])) $post['like_count'] = 0;
            if (!isset($post['comment_count'])) $post['comment_count'] = 0;
            if (!isset($post['is_active'])) $post['is_active'] = true;
            return ['success' => true, 'post' => $post];
        }
    }
    return ['success' => false, 'message' => '帖子不存在'];
}

function checkLikeStatus($postId) {
    global $likeFile;
    $userIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $likeKey = $postId . '|' . $userIp;
    $likes = readLines($likeFile);
    return ['success' => true, 'is_liked' => in_array($likeKey, $likes)];
}

function getPosts($type = 'latest', $page = 1, $pageSize = 10) {
    global $dataFile;
    $posts = [];
    $lines = readLines($dataFile);
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post) {
            if (!isset($post['category'])) $post['category'] = '普通';
            if (!isset($post['view_count'])) $post['view_count'] = 0;
            if (!isset($post['image'])) $post['image'] = '';
            if (!isset($post['like_count'])) $post['like_count'] = 0;
            if (!isset($post['comment_count'])) $post['comment_count'] = 0;
            if (!isset($post['is_active'])) $post['is_active'] = true;
            if ($post['is_active'] === false) continue;
            $posts[] = $post;
        }
    }
    switch ($type) {
        case 'hot':
            usort($posts, function($a, $b) {
                if ($b['view_count'] != $a['view_count']) return $b['view_count'] <=> $a['view_count'];
                return $b['timestamp'] <=> $a['timestamp'];
            });
            break;
        case 'expose':
            $posts = array_values(array_filter($posts, fn($p) => $p['category'] === '挂人'));
            usort($posts, fn($a, $b) => $b['timestamp'] <=> $a['timestamp']);
            break;
        default:
            usort($posts, fn($a, $b) => $b['timestamp'] <=> $a['timestamp']);
            break;
    }
    $total = count($posts);
    $offset = ($page - 1) * $pageSize;
    $paginatedPosts = array_slice($posts, $offset, $pageSize);
    $hasMore = ($offset + $pageSize) < $total;
    return [
        'list' => $paginatedPosts,
        'pagination' => ['total' => $total, 'current_page' => $page, 'page_size' => $pageSize, 'has_more' => $hasMore]
    ];
}

function incrementView($postId) {
    global $dataFile;
    $lines = readLines($dataFile);
    $newLines = [];
    $found = false;
    $post = null;
    foreach ($lines as $line) {
        $p = json_decode($line, true);
        if ($p && $p['id'] === $postId) {
            $p['view_count'] = ($p['view_count'] ?? 0) + 1;
            $post = $p;
            $found = true;
            $newLines[] = json_encode($p, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    if ($found) {
        writeLines($dataFile, $newLines);
        return ['success' => true, 'post' => $post];
    }
    return ['success' => false, 'message' => '帖子不存在'];
}

function savePost($postData, $file = null) {
    global $dataFile;
    $author = htmlspecialchars(trim($postData['author'] ?? '用户'), ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars(trim($postData['content'] ?? ''), ENT_QUOTES, 'UTF-8');
    $category = htmlspecialchars(trim($postData['category'] ?? '普通'), ENT_QUOTES, 'UTF-8');
    $imagePath = '';
    if (empty($content)) return ['success' => false, 'message' => '发布内容不能为空'];
    if ($file && $file['error'] !== UPLOAD_ERR_NO_FILE) {
        $uploadResult = uploadImage($file);
        if (!$uploadResult['success']) return $uploadResult;
        $imagePath = $uploadResult['path'];
    }
    $newPost = [
        'id' => uniqid(),
        'author' => $author ?: '用户',
        'content' => $content,
        'category' => $category,
        'image' => $imagePath,
        'view_count' => 0,
        'like_count' => 0,
        'comment_count' => 0,
        'is_active' => true,
        'timestamp' => time(),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '未知'
    ];
    appendLine($dataFile, json_encode($newPost, JSON_UNESCAPED_UNICODE));
    $today = todayStr();
    $dailyFile = 'data/daily_' . $today . '.txt';
    $daily = ['posts' => 0, 'views' => 0];
    if (file_exists($dailyFile)) {
        $daily = json_decode(file_get_contents($dailyFile), true) ?: ['posts' => 0, 'views' => 0];
    }
    $daily['posts']++;
    safeWrite($dailyFile, json_encode($daily, JSON_UNESCAPED_UNICODE));
    return ['success' => true, 'message' => '发布成功！'];
}

function deletePost($postId, $password) {
    global $dataFile, $passFile;
    if (!file_exists($passFile) || trim(file_get_contents($passFile)) !== $password) {
        return ['success' => false, 'message' => '管理密码错误'];
    }
    $lines = readLines($dataFile);
    $newLines = [];
    $found = false;
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && $post['id'] === $postId) {
            $found = true;
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) return ['success' => false, 'message' => '未找到该内容'];
    writeLines($dataFile, $newLines);
    return ['success' => true, 'message' => '删除成功'];
}

function likePost($postId) {
    global $dataFile, $likeFile;
    $userIp = $_SERVER['REMOTE_ADDR'] ?? bin2hex(random_bytes(8));
    $likeKey = $postId . '|' . $userIp;
    $likes = readLines($likeFile);
    if (in_array($likeKey, $likes)) {
        return ['success' => false, 'message' => '您已经点赞过啦'];
    }
    $lines = readLines($dataFile);
    $newLines = [];
    $postFound = false;
    $updatedLikeCount = 0;
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && $post['id'] === $postId) {
            $post['like_count'] = ($post['like_count'] ?? 0) + 1;
            $updatedLikeCount = $post['like_count'];
            $newLines[] = json_encode($post, JSON_UNESCAPED_UNICODE);
            $postFound = true;
        } else {
            $newLines[] = $line;
        }
    }
    if (!$postFound) return ['success' => false, 'message' => '帖子不存在'];
    writeLines($dataFile, $newLines);
    appendLine($likeFile, $likeKey);
    return ['success' => true, 'message' => '点赞成功', 'like_count' => $updatedLikeCount];
}

function saveComment($commentData) {
    global $commentFile, $dataFile;
    $postId = htmlspecialchars(trim($commentData['post_id'] ?? ''), ENT_QUOTES, 'UTF-8');
    $author = htmlspecialchars(trim($commentData['author'] ?? '匿名用户'), ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars(trim($commentData['content'] ?? ''), ENT_QUOTES, 'UTF-8');
    if (empty($postId) || empty($content)) return ['success' => false, 'message' => '评论内容不能为空'];
    $newComment = [
        'id' => uniqid(),
        'post_id' => $postId,
        'author' => $author ?: '匿名用户',
        'content' => $content,
        'timestamp' => time(),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '未知'
    ];
    appendLine($commentFile, json_encode($newComment, JSON_UNESCAPED_UNICODE));
    $lines = readLines($dataFile);
    $newLines = [];
    $updatedCommentCount = 0;
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && $post['id'] === $postId) {
            $post['comment_count'] = ($post['comment_count'] ?? 0) + 1;
            $updatedCommentCount = $post['comment_count'];
            $newLines[] = json_encode($post, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    writeLines($dataFile, $newLines);
    return ['success' => true, 'message' => '评论发布成功', 'comment' => $newComment, 'comment_count' => $updatedCommentCount];
}

function getComments($postId) {
    global $commentFile;
    $comments = [];
    $lines = readLines($commentFile);
    foreach ($lines as $line) {
        $comment = json_decode($line, true);
        if ($comment && $comment['post_id'] === $postId) {
            $comments[] = $comment;
        }
    }
    usort($comments, fn($a, $b) => $b['timestamp'] <=> $a['timestamp']);
    return ['success' => true, 'comments' => $comments, 'total' => count($comments)];
}

function getAnnouncements($page = 1, $pageSize = 20, $activeOnly = true) {
    global $announcementFile;
    $now = time();
    $announcements = [];
    $lines = readLines($announcementFile);
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if (!$ann) continue;
        if (!empty($ann['expire_at']) && $ann['expire_at'] < $now && $ann['is_active']) {
            $ann['is_active'] = false;
            updateAnnouncementInFile($ann);
        }
        if (!empty($ann['publish_at']) && $ann['publish_at'] > $now) {
            if ($activeOnly) continue;
        }
        if ($activeOnly && !$ann['is_active']) continue;
        $announcements[] = $ann;
    }
    usort($announcements, function($a, $b) {
        if ($a['is_pinned'] != $b['is_pinned']) return $b['is_pinned'] <=> $a['is_pinned'];
        return $b['created_at'] <=> $a['created_at'];
    });
    $total = count($announcements);
    $offset = ($page - 1) * $pageSize;
    $paginated = array_slice($announcements, $offset, $pageSize);
    return [
        'success' => true,
        'list' => $paginated,
        'pagination' => ['total' => $total, 'current_page' => $page, 'page_size' => $pageSize, 'has_more' => ($offset + $pageSize) < $total]
    ];
}

function updateAnnouncementInFile($updatedAnn) {
    global $announcementFile;
    $lines = readLines($announcementFile);
    $newLines = [];
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann && $ann['id'] === $updatedAnn['id']) {
            $newLines[] = json_encode($updatedAnn, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    writeLines($announcementFile, $newLines);
}

function createAnnouncement($data) {
    global $announcementFile;
    $title = htmlspecialchars(trim($data['title'] ?? ''), ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars(trim($data['content'] ?? ''), ENT_QUOTES, 'UTF-8');
    $author = htmlspecialchars(trim($data['author'] ?? '管理员'), ENT_QUOTES, 'UTF-8');
    $publishAt = intval($data['publish_at'] ?? 0);
    $expireAt = intval($data['expire_at'] ?? 0);
    $isPinned = !empty($data['is_pinned']);
    if (empty($title) || empty($content)) {
        return ['success' => false, 'message' => '标题和内容不能为空'];
    }
    if ($isPinned) {
        unpinAllAnnouncements();
    }
    $now = time();
    $announcement = [
        'id' => uniqid(),
        'title' => $title,
        'content' => $content,
        'author' => $author,
        'is_pinned' => $isPinned,
        'is_active' => true,
        'created_at' => $now,
        'updated_at' => $now,
        'publish_at' => $publishAt > 0 ? $publishAt : $now,
        'expire_at' => $expireAt
    ];
    appendLine($announcementFile, json_encode($announcement, JSON_UNESCAPED_UNICODE));
    writeLog('创建公告', '标题: ' . $title);
    return ['success' => true, 'message' => '公告创建成功', 'announcement' => $announcement];
}

function updateAnnouncement($data) {
    global $announcementFile;
    $id = $data['id'] ?? '';
    if (empty($id)) return ['success' => false, 'message' => '缺少公告ID'];
    $lines = readLines($announcementFile);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann && $ann['id'] === $id) {
            $found = true;
            if (isset($data['title'])) $ann['title'] = htmlspecialchars(trim($data['title']), ENT_QUOTES, 'UTF-8');
            if (isset($data['content'])) $ann['content'] = htmlspecialchars(trim($data['content']), ENT_QUOTES, 'UTF-8');
            if (isset($data['publish_at'])) $ann['publish_at'] = intval($data['publish_at']);
            if (isset($data['expire_at'])) $ann['expire_at'] = intval($data['expire_at']);
            $ann['updated_at'] = time();
            $newLines[] = json_encode($ann, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) return ['success' => false, 'message' => '公告不存在'];
    writeLines($announcementFile, $newLines);
    writeLog('编辑公告', 'ID: ' . $id);
    return ['success' => true, 'message' => '公告更新成功'];
}

function deleteAnnouncement($id) {
    global $announcementFile;
    if (empty($id)) return ['success' => false, 'message' => '缺少公告ID'];
    $lines = readLines($announcementFile);
    $newLines = [];
    $found = false;
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann && $ann['id'] === $id) {
            $found = true;
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) return ['success' => false, 'message' => '公告不存在'];
    writeLines($announcementFile, $newLines);
    writeLog('删除公告', 'ID: ' . $id);
    return ['success' => true, 'message' => '公告删除成功'];
}

function unpinAllAnnouncements() {
    global $announcementFile;
    $lines = readLines($announcementFile);
    $newLines = [];
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann && $ann['is_pinned']) {
            $ann['is_pinned'] = false;
            $newLines[] = json_encode($ann, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    writeLines($announcementFile, $newLines);
}

function pinAnnouncement($id) {
    global $announcementFile;
    if (empty($id)) return ['success' => false, 'message' => '缺少公告ID'];
    $lines = readLines($announcementFile);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann) {
            if ($ann['id'] === $id) {
                $ann['is_pinned'] = !$ann['is_pinned'];
                $found = true;
                $action = $ann['is_pinned'] ? '置顶' : '取消置顶';
            } else {
                if ($ann['is_pinned']) $ann['is_pinned'] = false;
            }
            $newLines[] = json_encode($ann, JSON_UNESCAPED_UNICODE);
        }
    }
    if (!$found) return ['success' => false, 'message' => '公告不存在'];
    writeLines($announcementFile, $newLines);
    writeLog($action ?? '切换置顶', '公告ID: ' . $id);
    return ['success' => true, 'message' => ($action ?? '操作') . '成功'];
}

function toggleAnnouncement($id) {
    global $announcementFile;
    if (empty($id)) return ['success' => false, 'message' => '缺少公告ID'];
    $lines = readLines($announcementFile);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann && $ann['id'] === $id) {
            $ann['is_active'] = !$ann['is_active'];
            $ann['updated_at'] = time();
            $found = true;
            $action = $ann['is_active'] ? '上架' : '下架';
            $newLines[] = json_encode($ann, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) return ['success' => false, 'message' => '公告不存在'];
    writeLines($announcementFile, $newLines);
    writeLog($action ?? '切换上下架', '公告ID: ' . $id);
    return ['success' => true, 'message' => ($action ?? '操作') . '成功'];
}

function getPinnedAnnouncement() {
    global $announcementFile;
    $now = time();
    $lines = readLines($announcementFile);
    foreach ($lines as $line) {
        $ann = json_decode($line, true);
        if ($ann && $ann['is_pinned'] && $ann['is_active']) {
            if (empty($ann['publish_at']) || $ann['publish_at'] <= $now) {
                if (empty($ann['expire_at']) || $ann['expire_at'] > $now) {
                    return ['success' => true, 'announcement' => $ann];
                }
            }
        }
    }
    return ['success' => false, 'message' => '暂无置顶公告'];
}

function adminLogin($password) {
    global $passFile;
    if (!file_exists($passFile)) return ['success' => false, 'message' => '系统错误'];
    $stored = trim(file_get_contents($passFile));
    if ($stored === $password) {
        writeLog('管理员登录', '登录成功');
        return ['success' => true, 'message' => '登录成功'];
    }
    return ['success' => false, 'message' => '密码错误'];
}

function adminChangePassword($oldPass, $newPass) {
    global $passFile;
    if (!file_exists($passFile)) return ['success' => false, 'message' => '系统错误'];
    $stored = trim(file_get_contents($passFile));
    if ($stored !== $oldPass) return ['success' => false, 'message' => '原密码错误'];
    if (strlen($newPass) < 6) return ['success' => false, 'message' => '新密码至少6位'];
    safeWrite($passFile, $newPass);
    writeLog('修改密码', '密码已修改');
    return ['success' => true, 'message' => '密码修改成功'];
}

function adminStats() {
    global $dataFile, $commentFile;
    $lines = readLines($dataFile);
    $totalPosts = count($lines);
    $totalViews = 0;
    $totalLikes = 0;
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post) {
            $totalViews += ($post['view_count'] ?? 0);
            $totalLikes += ($post['like_count'] ?? 0);
        }
    }
    $commentLines = readLines($commentFile);
    $totalComments = count($commentLines);
    $today = todayStr();
    $dailyFile = 'data/daily_' . $today . '.txt';
    $daily = ['posts' => 0, 'views' => 0];
    if (file_exists($dailyFile)) {
        $daily = json_decode(file_get_contents($dailyFile), true) ?: $daily;
    }
    $todayViews = 0;
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && isset($post['timestamp']) && date('Y-m-d', $post['timestamp']) === $today) {
            $todayViews += ($post['view_count'] ?? 0);
        }
    }
    $daily['views'] = $todayViews;
    return [
        'success' => true,
        'stats' => [
            'total_posts' => $totalPosts,
            'total_comments' => $totalComments,
            'total_views' => $totalViews,
            'total_likes' => $totalLikes,
            'today_posts' => $daily['posts'],
            'today_views' => $daily['views']
        ]
    ];
}

function adminLogs($page = 1, $pageSize = 50) {
    global $logFile;
    $lines = readLines($logFile);
    $logs = [];
    foreach ($lines as $line) {
        $log = json_decode($line, true);
        if ($log) $logs[] = $log;
    }
    usort($logs, fn($a, $b) => strcmp($b['time'], $a['time']));
    $total = count($logs);
    $offset = ($page - 1) * $pageSize;
    $paginated = array_slice($logs, $offset, $pageSize);
    return [
        'success' => true,
        'logs' => $paginated,
        'pagination' => ['total' => $total, 'current_page' => $page, 'page_size' => $pageSize, 'has_more' => ($offset + $pageSize) < $total]
    ];
}

function adminTogglePost($postId) {
    global $dataFile;
    if (empty($postId)) return ['success' => false, 'message' => '缺少帖子ID'];
    $lines = readLines($dataFile);
    $found = false;
    $newLines = [];
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && $post['id'] === $postId) {
            $post['is_active'] = !($post['is_active'] ?? true);
            $found = true;
            $action = $post['is_active'] ? '上架帖子' : '下架帖子';
            $newLines[] = json_encode($post, JSON_UNESCAPED_UNICODE);
        } else {
            $newLines[] = $line;
        }
    }
    if (!$found) return ['success' => false, 'message' => '帖子不存在'];
    writeLines($dataFile, $newLines);
    writeLog($action ?? '切换帖子状态', '帖子ID: ' . $postId);
    return ['success' => true, 'message' => ($action ?? '操作') . '成功'];
}

function getAllPosts($page = 1, $pageSize = 50) {
    global $dataFile;
    $posts = [];
    $lines = readLines($dataFile);
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post) {
            if (!isset($post['category'])) $post['category'] = '普通';
            if (!isset($post['view_count'])) $post['view_count'] = 0;
            if (!isset($post['image'])) $post['image'] = '';
            if (!isset($post['like_count'])) $post['like_count'] = 0;
            if (!isset($post['comment_count'])) $post['comment_count'] = 0;
            if (!isset($post['is_active'])) $post['is_active'] = true;
            $posts[] = $post;
        }
    }
    usort($posts, fn($a, $b) => $b['timestamp'] <=> $a['timestamp']);
    $total = count($posts);
    $offset = ($page - 1) * $pageSize;
    $paginated = array_slice($posts, $offset, $pageSize);
    return [
        'success' => true,
        'posts' => $paginated,
        'pagination' => ['total' => $total, 'current_page' => $page, 'page_size' => $pageSize, 'has_more' => ($offset + $pageSize) < $total]
    ];
}

function getDailyStats() {
    $today = todayStr();
    $dailyFile = 'data/daily_' . $today . '.txt';
    $daily = ['posts' => 0, 'views' => 0];
    if (file_exists($dailyFile)) {
        $daily = json_decode(file_get_contents($dailyFile), true) ?: $daily;
    }
    global $dataFile;
    $lines = readLines($dataFile);
    $todayViews = 0;
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && isset($post['timestamp']) && date('Y-m-d', $post['timestamp']) === $today) {
            $todayViews += ($post['view_count'] ?? 0);
        }
    }
    $daily['views'] = $todayViews;
    return ['success' => true, 'daily' => $daily];
}

switch ($action) {
    case 'get':
        $type = $_GET['type'] ?? 'latest';
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(50, intval($_GET['pageSize'] ?? 10)));
        $result = getPosts($type, $page, $pageSize);
        echo json_encode(['success' => true, 'posts' => $result['list'], 'pagination' => $result['pagination']], JSON_UNESCAPED_UNICODE);
        break;
    case 'post':
        $result = savePost($_POST, $_FILES['image'] ?? null);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = deletePost($input['id'] ?? '', $input['password'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'like':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = likePost($input['id'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'comment':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = saveComment($input);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'get_comments':
        $postId = $_GET['post_id'] ?? '';
        $result = getComments($postId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'get_post':
        $postId = $_GET['post_id'] ?? '';
        $result = getPostDetail($postId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'check_like':
        $postId = $_GET['post_id'] ?? '';
        $result = checkLikeStatus($postId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'increment_view':
        $postId = $_GET['post_id'] ?? '';
        $result = incrementView($postId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(50, intval($_GET['pageSize'] ?? 20)));
        $activeOnly = ($_GET['active_only'] ?? '1') === '1';
        $result = getAnnouncements($page, $pageSize, $activeOnly);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_create':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = createAnnouncement($input);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_update':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = updateAnnouncement($input);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = deleteAnnouncement($input['id'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_pin':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = pinAnnouncement($input['id'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_toggle':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = toggleAnnouncement($input['id'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_pinned':
        $result = getPinnedAnnouncement();
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_check_hide':
        $isHidden = checkHideAnnounce();
        echo json_encode(['success' => true, 'is_hidden' => $isHidden], JSON_UNESCAPED_UNICODE);
        break;
    case 'announcement_set_hide':
        $result = setHideAnnounce();
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'admin_login':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = adminLogin($input['password'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'admin_change_password':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = adminChangePassword($input['old_password'] ?? '', $input['new_password'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'admin_stats':
        $result = adminStats();
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'admin_logs':
        $page = max(1, intval($_GET['page'] ?? 1));
        $result = adminLogs($page);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'admin_toggle_post':
        $input = json_decode(file_get_contents('php://input'), true);
        $result = adminTogglePost($input['id'] ?? '');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'admin_get_all_posts':
        $page = max(1, intval($_GET['page'] ?? 1));
        $result = getAllPosts($page);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    case 'daily_stats':
        $result = getDailyStats();
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        break;
    default:
        echo json_encode(['success' => false, 'message' => '无效的请求'], JSON_UNESCAPED_UNICODE);
        break;
}
?>
