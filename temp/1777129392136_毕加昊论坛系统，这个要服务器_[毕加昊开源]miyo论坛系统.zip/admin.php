<?php
$passFile = 'data/password.txt';
if (!file_exists($passFile)) {
    file_put_contents($passFile, 'lhnb081216');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - 孝泉师范学生社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal; font-style: normal; font-display: swap;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif; }
        body {
            background: linear-gradient(135deg, #f3f0ff 0%, #e9e3f8 100%);
            min-height: 100vh; color: #333; background-attachment: fixed;
        }
        .glass {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 32px rgba(90, 24, 154, 0.08);
        }
        .admin-header {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(12px);
            padding: 15px 25px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #f0f0f0;
            position: sticky; top: 0; z-index: 100;
        }
        .admin-logo {
            font-size: 1.3rem; font-weight: 600; color: #5a189a;
            display: flex; align-items: center; gap: 10px;
        }
        .admin-header-actions { display: flex; gap: 10px; align-items: center; }
        .header-btn {
            padding: 8px 16px; border-radius: 8px; border: none;
            font-size: 0.9rem; cursor: pointer; transition: all 0.3s;
            display: flex; align-items: center; gap: 6px;
        }
        .header-btn.primary { background: #5a189a; color: white; }
        .header-btn.primary:hover { background: #7b2cbf; }
        .header-btn.secondary { background: rgba(90,24,154,0.1); color: #5a189a; }
        .header-btn.secondary:hover { background: rgba(90,24,154,0.2); }
        .admin-layout { display: flex; min-height: calc(100vh - 62px); }
        .admin-sidebar {
            width: 220px; background: rgba(255,255,255,0.8);
            backdrop-filter: blur(10px); padding: 20px 0;
            border-right: 1px solid rgba(255,255,255,0.3);
            flex-shrink: 0;
        }
        .sidebar-nav-item {
            display: flex; align-items: center; gap: 10px;
            padding: 12px 20px; color: #666; text-decoration: none;
            cursor: pointer; transition: all 0.3s; border-left: 3px solid transparent;
            font-size: 0.95rem;
        }
        .sidebar-nav-item:hover { background: rgba(90,24,154,0.05); color: #5a189a; }
        .sidebar-nav-item.active {
            background: rgba(90,24,154,0.1); color: #5a189a;
            border-left-color: #5a189a; font-weight: 600;
        }
        .sidebar-nav-item i { width: 20px; text-align: center; }
        .admin-main { flex: 1; padding: 25px; overflow-y: auto; }
        .admin-panel { display: none; }
        .admin-panel.active { display: block; }
        .panel-title {
            font-size: 1.3rem; font-weight: 600; color: #333;
            margin-bottom: 20px; display: flex; align-items: center; gap: 10px;
        }
        .login-wrapper {
            display: flex; align-items: center; justify-content: center;
            min-height: calc(100vh - 62px);
        }
        .login-card {
            width: 100%; max-width: 400px; padding: 40px; text-align: center;
        }
        .login-card h2 {
            color: #5a189a; margin-bottom: 10px;
            display: flex; align-items: center; justify-content: center; gap: 10px;
        }
        .login-card p { color: #666; margin-bottom: 25px; font-size: 0.9rem; }
        .form-group { margin-bottom: 16px; text-align: left; }
        .form-group label {
            display: block; margin-bottom: 6px; font-weight: 600;
            color: #555; font-size: 0.9rem;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 16px; border: 1px solid #e0e0e0;
            border-radius: 10px; font-size: 0.95rem; transition: all 0.3s;
            background: rgba(255,255,255,0.6);
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: #5a189a;
            box-shadow: 0 0 0 3px rgba(90,24,154,0.1);
        }
        .form-group textarea { min-height: 100px; resize: vertical; }
        .btn-primary {
            width: 100%; padding: 13px;
            background: linear-gradient(135deg, #5a189a, #7b2cbf);
            color: white; border: none; border-radius: 10px;
            font-size: 1rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s; display: flex; align-items: center;
            justify-content: center; gap: 8px;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(90,24,154,0.3); }
        .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        .msg { margin-top: 12px; padding: 10px; border-radius: 8px; font-size: 0.9rem; }
        .msg.error { background: #ffebee; color: #c62828; }
        .msg.success { background: #e8f5e9; color: #2e7d32; }
        .stats-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px; margin-bottom: 25px;
        }
        .stat-card {
            padding: 20px; text-align: center;
        }
        .stat-icon {
            width: 50px; height: 50px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 12px; font-size: 1.3rem;
        }
        .stat-icon.purple { background: rgba(90,24,154,0.1); color: #5a189a; }
        .stat-icon.blue { background: rgba(33,150,243,0.1); color: #2196f3; }
        .stat-icon.orange { background: rgba(255,152,0,0.1); color: #ff9800; }
        .stat-icon.green { background: rgba(76,175,80,0.1); color: #4caf50; }
        .stat-number { font-size: 1.8rem; font-weight: 700; color: #333; }
        .stat-label { font-size: 0.85rem; color: #888; margin-top: 4px; }
        .data-table {
            width: 100%; border-collapse: collapse;
        }
        .data-table th {
            background: rgba(90,24,154,0.05); padding: 12px 15px;
            text-align: left; font-weight: 600; color: #555;
            font-size: 0.85rem; border-bottom: 2px solid #f0f0f0;
        }
        .data-table td {
            padding: 12px 15px; border-bottom: 1px solid #f5f5f5;
            font-size: 0.9rem; color: #444; vertical-align: middle;
        }
        .data-table tr:hover td { background: rgba(90,24,154,0.02); }
        .table-wrapper {
            overflow-x: auto; border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.3);
            background: rgba(255,255,255,0.7);
        }
        .action-btn {
            padding: 6px 12px; border-radius: 6px; border: none;
            font-size: 0.8rem; cursor: pointer; transition: all 0.2s;
            display: inline-flex; align-items: center; gap: 4px;
            margin-right: 5px;
        }
        .action-btn.edit { background: #e3f2fd; color: #1976d2; }
        .action-btn.edit:hover { background: #bbdefb; }
        .action-btn.delete { background: #ffebee; color: #c62828; }
        .action-btn.delete:hover { background: #ffcdd2; }
        .action-btn.pin { background: #fff3e0; color: #e65100; }
        .action-btn.pin:hover { background: #ffe0b2; }
        .action-btn.toggle { background: #e8f5e9; color: #2e7d32; }
        .action-btn.toggle:hover { background: #c8e6c9; }
        .action-btn.toggle.off { background: #ffebee; color: #c62828; }
        .status-badge {
            padding: 3px 10px; border-radius: 12px;
            font-size: 0.75rem; font-weight: 600;
        }
        .status-badge.active { background: #e8f5e9; color: #2e7d32; }
        .status-badge.inactive { background: #ffebee; color: #c62828; }
        .status-badge.pinned { background: #fff3e0; color: #e65100; }
        .toolbar {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 15px; flex-wrap: wrap; gap: 10px;
        }
        .toolbar-left { display: flex; align-items: center; gap: 10px; }
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.45); backdrop-filter: blur(6px);
            z-index: 1000; display: none;
            align-items: center; justify-content: center; padding: 20px;
        }
        .modal-overlay.show { display: flex; }
        .modal-box {
            width: 100%; max-width: 550px; max-height: 85vh;
            overflow-y: auto; padding: 30px; position: relative;
            animation: slideUp 0.3s ease;
        }
        .modal-close {
            position: absolute; top: 15px; right: 15px;
            width: 34px; height: 34px; border-radius: 50%;
            background: rgba(255,255,255,0.9); border: none;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px; cursor: pointer; color: #333;
            transition: all 0.2s;
        }
        .modal-close:hover { background: #5a189a; color: white; }
        .modal-title {
            font-size: 1.2rem; font-weight: 600; color: #333;
            margin-bottom: 20px;
        }
        .log-item {
            padding: 10px 15px; border-bottom: 1px solid #f5f5f5;
            display: flex; align-items: center; gap: 12px;
            font-size: 0.85rem;
        }
        .log-time { color: #999; min-width: 140px; }
        .log-action { color: #5a189a; font-weight: 600; min-width: 100px; }
        .log-detail { color: #666; flex: 1; }
        .log-ip { color: #aaa; min-width: 100px; text-align: right; }
        .loading { text-align: center; padding: 40px; color: #888; }
        .empty-table { text-align: center; padding: 30px; color: #999; }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        @media (max-width: 768px) {
            .admin-layout { flex-direction: column; }
            .admin-sidebar {
                width: 100%; display: flex; overflow-x: auto;
                padding: 10px; border-right: none;
                border-bottom: 1px solid rgba(255,255,255,0.3);
            }
            .sidebar-nav-item {
                padding: 10px 15px; border-left: none;
                white-space: nowrap; font-size: 0.85rem;
                border-bottom: 3px solid transparent;
            }
            .sidebar-nav-item.active { border-bottom-color: #5a189a; border-left-color: transparent; }
            .admin-main { padding: 15px; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .stat-number { font-size: 1.4rem; }
            .data-table th, .data-table td { padding: 8px 10px; font-size: 0.8rem; }
            .action-btn { padding: 5px 8px; font-size: 0.75rem; }
            .header-btn span { display: none; }
        }
    </style>
</head>
<body>
    <div id="loginSection" class="login-wrapper">
        <div class="login-card glass">
            <h2><i class="fas fa-user-shield"></i> 管理后台</h2>
            <p>请输入管理密码以进行操作</p>
            <div class="form-group">
                <label for="adminPass">管理密码</label>
                <input type="password" id="adminPass" placeholder="你来这里干什么？" onkeydown="if(event.key==='Enter')doLogin()">
            </div>
            <button class="btn-primary" id="loginBtn" onclick="doLogin()"><i class="fas fa-sign-in-alt"></i> 登录</button>
            <div class="msg" id="loginMsg"></div>
            <div style="margin-top:15px;">
                <a href="index.php" style="color:#5a189a;font-size:0.85rem;text-decoration:none;">← 返回前台</a>
            </div>
        </div>
    </div>
    <div id="manageSection" style="display:none;">
        <header class="admin-header">
            <div class="admin-logo"><i class="fas fa-user-shield"></i> 管理后台</div>
            <div class="admin-header-actions">
                <button class="header-btn secondary" onclick="showChangePassword()"><i class="fas fa-key"></i> <span>修改密码</span></button>
                <button class="header-btn secondary" onclick="window.location.href='index.php'"><i class="fas fa-arrow-left"></i> <span>返回前台</span></button>
                <button class="header-btn primary" onclick="doLogout()"><i class="fas fa-sign-out-alt"></i> <span>退出</span></button>
            </div>
        </header>
        <div class="admin-layout">
            <aside class="admin-sidebar">
                <div class="sidebar-nav-item active" data-panel="stats"><i class="fas fa-chart-bar"></i> 数据统计</div>
                <div class="sidebar-nav-item" data-panel="announcements"><i class="fas fa-bullhorn"></i> 公告管理</div>
                <div class="sidebar-nav-item" data-panel="posts"><i class="fas fa-file-alt"></i> 内容管理</div>
                <div class="sidebar-nav-item" data-panel="logs"><i class="fas fa-history"></i> 操作日志</div>
            </aside>
            <main class="admin-main">
                <div class="admin-panel active" id="panel-stats">
                    <div class="panel-title"><i class="fas fa-chart-bar"></i> 数据统计</div>
                    <div class="stats-grid" id="statsGrid">
                        <div class="stat-card glass"><div class="stat-icon purple"><i class="fas fa-file-alt"></i></div><div class="stat-number" id="statPosts">-</div><div class="stat-label">总帖子数</div></div>
                        <div class="stat-card glass"><div class="stat-icon blue"><i class="fas fa-comments"></i></div><div class="stat-number" id="statComments">-</div><div class="stat-label">总评论数</div></div>
                        <div class="stat-card glass"><div class="stat-icon orange"><i class="fas fa-eye"></i></div><div class="stat-number" id="statViews">-</div><div class="stat-label">总浏览量</div></div>
                        <div class="stat-card glass"><div class="stat-icon green"><i class="fas fa-heart"></i></div><div class="stat-number" id="statLikes">-</div><div class="stat-label">总点赞数</div></div>
                    </div>
                    <div class="stats-grid">
                        <div class="stat-card glass"><div class="stat-icon purple"><i class="fas fa-plus-circle"></i></div><div class="stat-number" id="statTodayPosts">-</div><div class="stat-label">今日发布</div></div>
                        <div class="stat-card glass"><div class="stat-icon orange"><i class="fas fa-eye"></i></div><div class="stat-number" id="statTodayViews">-</div><div class="stat-label">今日浏览</div></div>
                    </div>
                </div>
                <div class="admin-panel" id="panel-announcements">
                    <div class="panel-title"><i class="fas fa-bullhorn"></i> 公告管理</div>
                    <div class="toolbar">
                        <div class="toolbar-left"></div>
                        <button class="btn-primary" style="width:auto;padding:10px 20px;" onclick="showCreateAnnouncement()"><i class="fas fa-plus"></i> 新建公告</button>
                    </div>
                    <div class="table-wrapper">
                        <table class="data-table">
                            <thead><tr><th>标题</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead>
                            <tbody id="annTableBody"><tr><td colspan="4" class="empty-table">加载中...</td></tr></tbody>
                        </table>
                    </div>
                </div>
                <div class="admin-panel" id="panel-posts">
                    <div class="panel-title"><i class="fas fa-file-alt"></i> 内容管理</div>
                    <div class="table-wrapper">
                        <table class="data-table">
                            <thead><tr><th>作者</th><th>内容</th><th>浏览</th><th>点赞</th><th>评论</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
                            <tbody id="postTableBody"><tr><td colspan="8" class="empty-table">加载中...</td></tr></tbody>
                        </table>
                    </div>
                </div>
                <div class="admin-panel" id="panel-logs">
                    <div class="panel-title"><i class="fas fa-history"></i> 操作日志</div>
                    <div class="table-wrapper">
                        <div id="logContainer">
                            <div class="log-item"><span class="log-time">加载中...</span></div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <div class="modal-overlay" id="modalOverlay">
        <div class="modal-box glass" id="modalBox">
            <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
            <div id="modalContent"></div>
        </div>
    </div>
    <script>
        let adminPass = '';
        function doLogin() {
            const pass = document.getElementById('adminPass').value;
            if (!pass) { showLoginMsg('请输入密码', 'error'); return; }
            fetch('api.php?action=admin_login', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({password: pass})
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    adminPass = pass;
                    document.getElementById('loginSection').style.display = 'none';
                    document.getElementById('manageSection').style.display = 'block';
                    loadStats(); loadAnnouncements(); loadPosts(); loadLogs();
                } else {
                    showLoginMsg(data.message, 'error');
                }
            })
            .catch(() => showLoginMsg('网络错误', 'error'));
        }
        function showLoginMsg(msg, type) {
            const el = document.getElementById('loginMsg');
            el.textContent = msg; el.className = 'msg ' + type;
        }
        function doLogout() {
            adminPass = '';
            document.getElementById('manageSection').style.display = 'none';
            document.getElementById('loginSection').style.display = 'flex';
            document.getElementById('adminPass').value = '';
        }
        document.querySelectorAll('.sidebar-nav-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.sidebar-nav-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                const panel = this.getAttribute('data-panel');
                document.querySelectorAll('.admin-panel').forEach(p => p.classList.remove('active'));
                document.getElementById('panel-' + panel).classList.add('active');
                if (panel === 'stats') loadStats();
                if (panel === 'announcements') loadAnnouncements();
                if (panel === 'posts') loadPosts();
                if (panel === 'logs') loadLogs();
            });
        });
        function openModal(html) {
            document.getElementById('modalContent').innerHTML = html;
            document.getElementById('modalOverlay').classList.add('show');
        }
        function closeModal() { document.getElementById('modalOverlay').classList.remove('show'); }
        document.getElementById('modalOverlay').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
        function loadStats() {
            fetch('api.php?action=admin_stats')
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const s = data.stats;
                    document.getElementById('statPosts').textContent = s.total_posts;
                    document.getElementById('statComments').textContent = s.total_comments;
                    document.getElementById('statViews').textContent = s.total_views;
                    document.getElementById('statLikes').textContent = s.total_likes;
                    document.getElementById('statTodayPosts').textContent = s.today_posts;
                    document.getElementById('statTodayViews').textContent = s.today_views;
                }
            });
        }
        function loadAnnouncements() {
            fetch('api.php?action=announcement_list&page=1&pageSize=100&active_only=0')
            .then(r => r.json())
            .then(data => {
                const tbody = document.getElementById('annTableBody');
                if (!data.success || !data.list || data.list.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="4" class="empty-table">暂无公告</td></tr>';
                    return;
                }
                let html = '';
                data.list.forEach(ann => {
                    const date = new Date(ann.created_at * 1000).toLocaleString('zh-CN');
                    let badges = '';
                    if (ann.is_pinned) badges += '<span class="status-badge pinned">置顶</span> ';
                    badges += ann.is_active ? '<span class="status-badge active">上架</span>' : '<span class="status-badge inactive">下架</span>';
                    html += `<tr>
                        <td>${ann.title}</td>
                        <td>${badges}</td>
                        <td style="white-space:nowrap">${date}</td>
                        <td style="white-space:nowrap">
                            <button class="action-btn pin" onclick="pinAnn('${ann.id}')"><i class="fas fa-thumbtack"></i></button>
                            <button class="action-btn toggle ${ann.is_active?'':'off'}" onclick="toggleAnn('${ann.id}')"><i class="fas fa-${ann.is_active?'eye':'eye-slash'}"></i></button>
                            <button class="action-btn edit" onclick="editAnn('${ann.id}')"><i class="fas fa-edit"></i></button>
                            <button class="action-btn delete" onclick="deleteAnn('${ann.id}')"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>`;
                });
                tbody.innerHTML = html;
            });
        }
        function showCreateAnnouncement() {
            openModal(`
                <div class="modal-title"><i class="fas fa-plus"></i> 新建公告</div>
                <div class="form-group"><label>标题</label><input id="annTitle" placeholder="公告标题"></div>
                <div class="form-group"><label>内容</label><textarea id="annContent" placeholder="公告内容"></textarea></div>
                <div class="form-group"><label>作者</label><input id="annAuthor" value="管理员"></div>
                <div class="form-group"><label>定时发布时间（可选，时间戳）</label><input id="annPublishAt" placeholder="留空则立即发布" type="number"></div>
                <div class="form-group"><label>过期时间（可选，时间戳）</label><input id="annExpireAt" placeholder="留空则永不过期" type="number"></div>
                <div class="form-group" style="display:flex;align-items:center;gap:10px;">
                    <input type="checkbox" id="annPinned" style="width:auto;"><label for="annPinned" style="margin:0;">设为置顶</label>
                </div>
                <button class="btn-primary" onclick="submitCreateAnn()"><i class="fas fa-save"></i> 创建</button>
            `);
        }
        function submitCreateAnn() {
            const data = {
                title: document.getElementById('annTitle').value,
                content: document.getElementById('annContent').value,
                author: document.getElementById('annAuthor').value,
                publish_at: parseInt(document.getElementById('annPublishAt').value) || 0,
                expire_at: parseInt(document.getElementById('annExpireAt').value) || 0,
                is_pinned: document.getElementById('annPinned').checked
            };
            if (!data.title || !data.content) { alert('标题和内容不能为空'); return; }
            fetch('api.php?action=announcement_create', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify(data)
            })
            .then(r => r.json())
            .then(r => { alert(r.message); if (r.success) { closeModal(); loadAnnouncements(); } });
        }
        function editAnn(id) {
            fetch('api.php?action=announcement_list&page=1&pageSize=100&active_only=0')
            .then(r => r.json())
            .then(data => {
                const ann = data.list.find(a => a.id === id);
                if (!ann) { alert('公告不存在'); return; }
                openModal(`
                    <div class="modal-title"><i class="fas fa-edit"></i> 编辑公告</div>
                    <div class="form-group"><label>标题</label><input id="editAnnTitle" value="${ann.title.replace(/"/g,'&quot;')}"></div>
                    <div class="form-group"><label>内容</label><textarea id="editAnnContent">${ann.content}</textarea></div>
                    <div class="form-group"><label>定时发布时间</label><input id="editAnnPublishAt" type="number" value="${ann.publish_at || ''}"></div>
                    <div class="form-group"><label>过期时间</label><input id="editAnnExpireAt" type="number" value="${ann.expire_at || ''}"></div>
                    <button class="btn-primary" onclick="submitEditAnn('${id}')"><i class="fas fa-save"></i> 保存</button>
                `);
            });
        }
        function submitEditAnn(id) {
            const data = {
                id: id,
                title: document.getElementById('editAnnTitle').value,
                content: document.getElementById('editAnnContent').value,
                publish_at: parseInt(document.getElementById('editAnnPublishAt').value) || 0,
                expire_at: parseInt(document.getElementById('editAnnExpireAt').value) || 0
            };
            fetch('api.php?action=announcement_update', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify(data)
            })
            .then(r => r.json())
            .then(r => { alert(r.message); if (r.success) { closeModal(); loadAnnouncements(); } });
        }
        function deleteAnn(id) {
            if (!confirm('确定删除此公告？')) return;
            fetch('api.php?action=announcement_delete', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({id: id})
            })
            .then(r => r.json())
            .then(r => { alert(r.message); if (r.success) loadAnnouncements(); });
        }
        function pinAnn(id) {
            fetch('api.php?action=announcement_pin', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({id: id})
            })
            .then(r => r.json())
            .then(r => { alert(r.message); if (r.success) loadAnnouncements(); });
        }
        function toggleAnn(id) {
            fetch('api.php?action=announcement_toggle', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({id: id})
            })
            .then(r => r.json())
            .then(r => { alert(r.message); if (r.success) loadAnnouncements(); });
        }
        function loadPosts() {
            fetch('api.php?action=admin_get_all_posts&page=1&pageSize=100')
            .then(r => r.json())
            .then(data => {
                const tbody = document.getElementById('postTableBody');
                if (!data.success || !data.posts || data.posts.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="8" class="empty-table">暂无帖子</td></tr>';
                    return;
                }
                let html = '';
                data.posts.forEach(post => {
                    const date = new Date(post.timestamp * 1000).toLocaleString('zh-CN');
                    const content = post.content.length > 30 ? post.content.substring(0,30) + '...' : post.content;
                    const status = post.is_active !== false
                        ? '<span class="status-badge active">上架</span>'
                        : '<span class="status-badge inactive">下架</span>';
                    html += `<tr>
                        <td>${post.author}</td>
                        <td title="${post.content.replace(/"/g,'&quot;')}">${content}</td>
                        <td>${post.view_count}</td>
                        <td>${post.like_count}</td>
                        <td>${post.comment_count}</td>
                        <td>${status}</td>
                        <td style="white-space:nowrap">${date}</td>
                        <td style="white-space:nowrap">
                            <button class="action-btn toggle ${post.is_active!==false?'':'off'}" onclick="togglePost('${post.id}')"><i class="fas fa-${post.is_active!==false?'eye':'eye-slash'}"></i></button>
                            <button class="action-btn delete" onclick="adminDeletePost('${post.id}')"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>`;
                });
                tbody.innerHTML = html;
            });
        }
        function togglePost(id) {
            fetch('api.php?action=admin_toggle_post', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({id: id})
            })
            .then(r => r.json())
            .then(r => { alert(r.message); if (r.success) loadPosts(); });
        }
        function adminDeletePost(id) {
            if (!confirm('确定删除此帖子？此操作不可撤销！')) return;
            fetch('api.php?action=delete', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({id: id, password: adminPass})
            })
            .then(r => r.json())
            .then(r => {
                if (r.message && r.message.includes('密码')) {
                    alert('密码验证失败，请重新登录'); doLogout();
                } else {
                    alert(r.message); if (r.success) loadPosts();
                }
            });
        }
        function loadLogs() {
            fetch('api.php?action=admin_logs&page=1&pageSize=100')
            .then(r => r.json())
            .then(data => {
                const container = document.getElementById('logContainer');
                if (!data.success || !data.logs || data.logs.length === 0) {
                    container.innerHTML = '<div class="log-item"><span class="log-time">暂无操作日志</span></div>';
                    return;
                }
                let html = '';
                data.logs.forEach(log => {
                    html += `<div class="log-item">
                        <span class="log-time">${log.time}</span>
                        <span class="log-action">${log.action}</span>
                        <span class="log-detail">${log.detail || '-'}</span>
                        <span class="log-ip">${log.ip || ''}</span>
                    </div>`;
                });
                container.innerHTML = html;
            });
        }
        function showChangePassword() {
            openModal(`
                <div class="modal-title"><i class="fas fa-key"></i> 修改密码</div>
                <div class="form-group"><label>原密码</label><input type="password" id="oldPass"></div>
                <div class="form-group"><label>新密码（至少6位）</label><input type="password" id="newPass"></div>
                <div class="form-group"><label>确认新密码</label><input type="password" id="confirmPass"></div>
                <button class="btn-primary" onclick="submitChangePass()"><i class="fas fa-save"></i> 修改</button>
            `);
        }
        function submitChangePass() {
            const oldP = document.getElementById('oldPass').value;
            const newP = document.getElementById('newPass').value;
            const confirmP = document.getElementById('confirmPass').value;
            if (newP !== confirmP) { alert('两次输入的新密码不一致'); return; }
            fetch('api.php?action=admin_change_password', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({old_password: oldP, new_password: newP})
            })
            .then(r => r.json())
            .then(r => {
                alert(r.message);
                if (r.success) { adminPass = newP; closeModal(); }
            });
        }
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('adminPass').addEventListener('keydown', function(e) {
                if (e.key === 'Enter') doLogin();
            });
        });
    </script>
</body>
</html>
