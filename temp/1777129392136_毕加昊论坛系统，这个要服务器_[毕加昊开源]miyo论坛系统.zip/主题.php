<?php
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>主题设置 - 孝泉师范学校学生社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal; font-style: normal; font-display: swap;
        }
    </style>
    <style>
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #333;
            --text-secondary: #666;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow-color: rgba(90, 24, 154, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #e0e0e0;
            --text-secondary: #aaa;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --glass-bg: rgba(30, 30, 60, 0.85);
            --glass-border: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --card-bg: rgba(30, 30, 60, 0.6);
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #2e7d32;
            --text-secondary: #558b2f;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.4);
            --shadow-color: rgba(46, 125, 50, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        * {
            -webkit-tap-highlight-color: transparent;
            margin: 0; padding: 0; box-sizing: border-box;
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif;
        }
        html, body {
            width: 100vw; height: 100vh; overflow: hidden;
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            background-attachment: fixed;
            color: var(--text-primary);
        }
        .glass {
            background: var(--glass-bg);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 16px;
            border: 1px solid var(--glass-border);
            box-shadow: 0 8px 32px var(--shadow-color);
        }
        .full-page-container {
            width: 100%; height: 100vh;
            display: flex; flex-direction: column; overflow: hidden;
        }
        .top-nav {
            width: 100%; height: 60px;
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 20px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px) saturate(180%);
            border-bottom: 1px solid var(--glass-border);
            flex-shrink: 0;
        }
        .back-btn {
            width: 38px; height: 38px; border-radius: 8px;
            background: var(--accent-light); border: none;
            color: var(--accent); font-size: 18px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: all 0.3s ease;
        }
        .back-btn:hover { background: var(--accent); color: white; }
        .nav-title { font-size: 1.2rem; font-weight: 600; color: var(--text-primary); }
        .nav-placeholder { width: 38px; }
        .main-content {
            flex: 1; width: 100%; padding: 20px;
            overflow-y: auto; display: flex; flex-direction: column; gap: 20px;
        }
        .section-title {
            font-size: 1.1rem; font-weight: 600; color: var(--text-primary);
            display: flex; align-items: center; gap: 8px;
            margin-bottom: 5px;
        }
        .theme-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        .theme-card {
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            position: relative;
        }
        .theme-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px var(--shadow-color);
        }
        .theme-card.active {
            border: 2px solid var(--accent);
            box-shadow: 0 0 0 3px var(--accent-light);
        }
        .theme-card.active::after {
            content: '\f00c';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            top: 10px; right: 10px;
            width: 24px; height: 24px;
            background: var(--accent);
            color: white;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 12px;
        }
        .theme-preview {
            width: 100%; height: 80px;
            border-radius: 10px;
            margin-bottom: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem;
        }
        .theme-name {
            font-size: 1rem; font-weight: 600; color: var(--text-primary);
            margin-bottom: 4px;
        }
        .theme-desc {
            font-size: 0.8rem; color: var(--text-secondary);
        }
        .preview-light {
            background: linear-gradient(135deg, #f3f0ff, #e9e3f8);
            color: #5a189a;
        }
        .preview-dark {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            color: #bb86fc;
        }
        .preview-mint {
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            color: #2e7d32;
        }
        .custom-section {
            padding: 20px;
        }
        .color-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-top: 10px;
        }
        .color-item {
            display: flex; align-items: center; gap: 10px;
        }
        .color-item label {
            font-size: 0.85rem; color: var(--text-secondary);
            min-width: 80px;
        }
        .color-item input[type="color"] {
            width: 40px; height: 32px;
            border: 1px solid var(--glass-border);
            border-radius: 6px; cursor: pointer;
            background: transparent;
            padding: 2px;
        }
        .btn-row {
            display: flex; gap: 12px; margin-top: 15px;
        }
        .save-btn {
            flex: 1;
            padding: 12px;
            background: linear-gradient(135deg, var(--accent), #7b2cbf);
            color: white;
            border: none; border-radius: 10px;
            font-size: 1rem; font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .save-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px var(--shadow-color); }
        .reset-btn {
            padding: 12px 20px;
            background: var(--accent-light);
            color: var(--accent);
            border: 1px solid var(--accent);
            border-radius: 10px;
            font-size: 1rem; font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .reset-btn:hover { background: var(--accent); color: white; }
        .toast {
            position: fixed; bottom: 80px; left: 50%;
            transform: translateX(-50%) translateY(20px);
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            color: var(--text-primary);
            padding: 12px 24px;
            border-radius: 30px;
            font-size: 0.9rem;
            box-shadow: 0 8px 30px var(--shadow-color);
            border: 1px solid var(--glass-border);
            opacity: 0;
            transition: all 0.3s ease;
            z-index: 3000;
            pointer-events: none;
        }
        .toast.show {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        @media (max-width: 768px) {
            .top-nav { height: 55px; padding: 0 15px; }
            .back-btn { width: 34px; height: 34px; font-size: 16px; }
            .nav-placeholder { width: 34px; }
            .main-content { padding: 15px; }
            .theme-grid { grid-template-columns: repeat(3, 1fr); gap: 10px; }
            .theme-card { padding: 15px 10px; }
            .theme-preview { height: 60px; font-size: 1.2rem; }
            .theme-name { font-size: 0.9rem; }
            .color-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="full-page-container">
        <nav class="top-nav">
            <button class="back-btn" id="backBtn"><i class="fas fa-arrow-left"></i></button>
            <div class="nav-title">主题设置</div>
            <div class="nav-placeholder"></div>
        </nav>
        <main class="main-content">
            <div>
                <div class="section-title"><i class="fas fa-palette"></i> 选择主题</div>
                <div class="theme-grid">
                    <div class="theme-card glass" data-theme-select="light">
                        <div class="theme-preview preview-light"><i class="fas fa-sun"></i></div>
                        <div class="theme-name">日间模式</div>
                        <div class="theme-desc">紫色渐变，清新优雅</div>
                    </div>
                    <div class="theme-card glass" data-theme-select="dark">
                        <div class="theme-preview preview-dark"><i class="fas fa-moon"></i></div>
                        <div class="theme-name">深色模式</div>
                        <div class="theme-desc">暗夜护眼，沉浸体验</div>
                    </div>
                    <div class="theme-card glass" data-theme-select="mint">
                        <div class="theme-preview preview-mint"><i class="fas fa-leaf"></i></div>
                        <div class="theme-name">薄荷绿</div>
                        <div class="theme-desc">清新绿调，自然舒适</div>
                    </div>
                </div>
            </div>
            <div class="custom-section glass">
                <div class="section-title"><i class="fas fa-sliders-h"></i> 自定义颜色</div>
                <div class="color-grid">
                    <div class="color-item">
                        <label>渐变起始色</label>
                        <input type="color" id="colorBgStart" value="#f3f0ff">
                    </div>
                    <div class="color-item">
                        <label>渐变结束色</label>
                        <input type="color" id="colorBgEnd" value="#e9e3f8">
                    </div>
                    <div class="color-item">
                        <label>主文字色</label>
                        <input type="color" id="colorTextPrimary" value="#333333">
                    </div>
                    <div class="color-item">
                        <label>次要文字色</label>
                        <input type="color" id="colorTextSecondary" value="#666666">
                    </div>
                    <div class="color-item">
                        <label>强调色</label>
                        <input type="color" id="colorAccent" value="#5a189a">
                    </div>
                    <div class="color-item">
                        <label>玻璃背景色</label>
                        <input type="color" id="colorGlassBg" value="#ffffff">
                    </div>
                </div>
                <div class="btn-row">
                    <button class="save-btn" id="saveCustomBtn"><i class="fas fa-save"></i> 保存自定义主题</button>
                    <button class="reset-btn" id="resetBtn"><i class="fas fa-undo"></i> 重置</button>
                </div>
            </div>
        </main>
    </div>
    <div class="toast" id="toast"></div>
    <script>
        const THEME_KEY = 'community_theme';
        const themes = {
            light: {
                '--bg-gradient-start': '#f3f0ff',
                '--bg-gradient-end': '#e9e3f8',
                '--text-primary': '#333',
                '--text-secondary': '#666',
                '--accent': '#5a189a',
                '--accent-light': 'rgba(90, 24, 154, 0.1)',
                '--glass-bg': 'rgba(255, 255, 255, 0.85)',
                '--glass-border': 'rgba(255, 255, 255, 0.3)',
                '--shadow-color': 'rgba(90, 24, 154, 0.08)',
                '--card-bg': 'rgba(255, 255, 255, 0.6)'
            },
            dark: {
                '--bg-gradient-start': '#1a1a2e',
                '--bg-gradient-end': '#16213e',
                '--text-primary': '#e0e0e0',
                '--text-secondary': '#aaa',
                '--accent': '#bb86fc',
                '--accent-light': 'rgba(187, 134, 252, 0.15)',
                '--glass-bg': 'rgba(30, 30, 60, 0.85)',
                '--glass-border': 'rgba(255, 255, 255, 0.1)',
                '--shadow-color': 'rgba(0, 0, 0, 0.3)',
                '--card-bg': 'rgba(30, 30, 60, 0.6)'
            },
            mint: {
                '--bg-gradient-start': '#e8f5e9',
                '--bg-gradient-end': '#c8e6c9',
                '--text-primary': '#2e7d32',
                '--text-secondary': '#558b2f',
                '--accent': '#2e7d32',
                '--accent-light': 'rgba(46, 125, 50, 0.1)',
                '--glass-bg': 'rgba(255, 255, 255, 0.85)',
                '--glass-border': 'rgba(255, 255, 255, 0.4)',
                '--shadow-color': 'rgba(46, 125, 50, 0.08)',
                '--card-bg': 'rgba(255, 255, 255, 0.6)'
            }
        };
        function showToast(msg) {
            const t = document.getElementById('toast');
            t.textContent = msg;
            t.classList.add('show');
            setTimeout(() => t.classList.remove('show'), 2000);
        }
        function applyTheme(themeName) {
            const t = themes[themeName];
            if (!t) return;
            Object.entries(t).forEach(([k, v]) => document.documentElement.style.setProperty(k, v));
            document.documentElement.setAttribute('data-theme', themeName === 'light' ? '' : themeName);
            if (themeName === 'light') document.documentElement.removeAttribute('data-theme');
            document.getElementById('colorBgStart').value = t['--bg-gradient-start'];
            document.getElementById('colorBgEnd').value = t['--bg-gradient-end'];
            document.getElementById('colorTextPrimary').value = t['--text-primary'].length === 4
                ? '#' + t['--text-primary'][1]+t['--text-primary'][1]+t['--text-primary'][2]+t['--text-primary'][2]+t['--text-primary'][3]+t['--text-primary'][3]
                : t['--text-primary'];
            document.getElementById('colorTextSecondary').value = t['--text-secondary'].length === 4
                ? '#' + t['--text-secondary'][1]+t['--text-secondary'][1]+t['--text-secondary'][2]+t['--text-secondary'][2]+t['--text-secondary'][3]+t['--text-secondary'][3]
                : t['--text-secondary'];
            document.getElementById('colorAccent').value = t['--accent'].length === 4
                ? '#' + t['--accent'][1]+t['--accent'][1]+t['--accent'][2]+t['--accent'][2]+t['--accent'][3]+t['--accent'][3]
                : t['--accent'];
            document.querySelectorAll('.theme-card').forEach(c => c.classList.remove('active'));
            const card = document.querySelector(`[data-theme-select="${themeName}"]`);
            if (card) card.classList.add('active');
        }
        function saveTheme(themeName) {
            localStorage.setItem(THEME_KEY, JSON.stringify({ name: themeName }));
            applyTheme(themeName);
            showToast('主题已保存！');
        }
        function saveCustomTheme() {
            const custom = {
                name: 'custom',
                vars: {
                    '--bg-gradient-start': document.getElementById('colorBgStart').value,
                    '--bg-gradient-end': document.getElementById('colorBgEnd').value,
                    '--text-primary': document.getElementById('colorTextPrimary').value,
                    '--text-secondary': document.getElementById('colorTextSecondary').value,
                    '--accent': document.getElementById('colorAccent').value,
                    '--accent-light': document.getElementById('colorAccent').value + '1a',
                    '--glass-bg': 'rgba(255, 255, 255, 0.85)',
                    '--glass-border': 'rgba(255, 255, 255, 0.3)',
                    '--shadow-color': document.getElementById('colorAccent').value + '14',
                    '--card-bg': 'rgba(255, 255, 255, 0.6)'
                }
            };
            Object.entries(custom.vars).forEach(([k, v]) => document.documentElement.style.setProperty(k, v));
            document.documentElement.removeAttribute('data-theme');
            localStorage.setItem(THEME_KEY, JSON.stringify(custom));
            document.querySelectorAll('.theme-card').forEach(c => c.classList.remove('active'));
            showToast('自定义主题已保存！');
        }
        document.addEventListener('DOMContentLoaded', () => {
            const saved = localStorage.getItem(THEME_KEY);
            if (saved) {
                try {
                    const s = JSON.parse(saved);
                    if (s.name === 'custom' && s.vars) {
                        Object.entries(s.vars).forEach(([k, v]) => document.documentElement.style.setProperty(k, v));
                        document.getElementById('colorBgStart').value = s.vars['--bg-gradient-start'];
                        document.getElementById('colorBgEnd').value = s.vars['--bg-gradient-end'];
                        document.getElementById('colorTextPrimary').value = s.vars['--text-primary'];
                        document.getElementById('colorTextSecondary').value = s.vars['--text-secondary'];
                        document.getElementById('colorAccent').value = s.vars['--accent'];
                    } else {
                        applyTheme(s.name || 'light');
                    }
                } catch(e) {
                    applyTheme('light');
                }
            } else {
                applyTheme('light');
            }
            document.querySelectorAll('.theme-card').forEach(card => {
                card.addEventListener('click', () => {
                    const theme = card.getAttribute('data-theme-select');
                    saveTheme(theme);
                });
            });
            document.getElementById('saveCustomBtn').addEventListener('click', saveCustomTheme);
            document.getElementById('resetBtn').addEventListener('click', () => {
                localStorage.removeItem(THEME_KEY);
                applyTheme('light');
                showToast('已重置为默认主题');
            });
            document.querySelectorAll('.color-item input[type="color"]').forEach(input => {
                input.addEventListener('input', () => {
                    const map = {
                        'colorBgStart': '--bg-gradient-start',
                        'colorBgEnd': '--bg-gradient-end',
                        'colorTextPrimary': '--text-primary',
                        'colorTextSecondary': '--text-secondary',
                        'colorAccent': '--accent'
                    };
                    const varName = map[input.id];
                    if (varName) document.documentElement.style.setProperty(varName, input.value);
                });
            });
            document.getElementById('backBtn').addEventListener('click', () => { window.location.href = 'index.php'; });
        });
    </script>
</body>
</html>
