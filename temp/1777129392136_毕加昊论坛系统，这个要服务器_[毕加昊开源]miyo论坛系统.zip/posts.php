<div class="fixed-tab-nav">
    <div class="tab-nav-wrapper">
        <button class="tab-item active" data-type="latest">最新</button>
        <button class="tab-item" data-type="hot">最热</button>
        <button class="tab-item" data-type="expose">挂人</button>
    </div>
</div>
<div id="fixed-status-container" class="fixed-status-container">
    <div class="status-content">
        <div class="loading"><i class="fas fa-spinner fa-spin"></i> 正在加载内容...</div>
    </div>
</div>
<section class="posts-container">
    <div id="posts-list"></div>
</section>
<style>
.fixed-tab-nav {
    position: fixed; top: 70px; left: 0; width: 100%; z-index: 1001;
    background: rgba(255, 255, 255, 0.35);
    backdrop-filter: blur(12px) saturate(180%);
    -webkit-backdrop-filter: blur(12px) saturate(180%);
    border-bottom: 1px solid var(--glass-border, rgba(255, 255, 255, 0.4));
}
.tab-nav-wrapper {
    display: flex; justify-content: center; align-items: center;
    gap: 15px; max-width: 1200px; margin: 0 auto;
    padding-left: 260px; padding-right: 20px; height: 60px;
    transition: padding-left 0.3s ease;
}
body.sidebar-hidden .tab-nav-wrapper { padding-left: 20px; }
.tab-item {
    background: transparent; border: none; padding: 10px 20px;
    flex: 0 1 100px; text-align: center; border-radius: 8px;
    font-size: 1rem; font-weight: 500;
    color: var(--text-secondary, #666); cursor: pointer;
    transition: all 0.3s ease;
}
.tab-item:hover, .tab-item.active {
    background: rgba(255, 255, 255, 0.5);
    color: var(--accent, #5a189a);
}
.fixed-status-container {
    position: fixed; top: 130px; bottom: 45px; left: 0; width: 100%;
    padding-left: 260px; z-index: 990; display: none;
    align-items: center; justify-content: center;
    transition: padding-left 0.3s ease;
}
body.sidebar-hidden .fixed-status-container { padding-left: 0; }
.status-content { width: 100%; max-width: 1200px; padding: 0 20px; text-align: center; }
#posts-list {
    display: flex; flex-direction: column;
    background: transparent; border-radius: 0; overflow: hidden;
}
.post-item {
    position: relative; padding: 14px 20px 14px 20px;
    border-bottom: 1px solid rgba(90, 24, 154, 0.06);
    transition: background 0.2s ease; background: transparent;
    height: 140px; overflow: hidden; cursor: pointer;
    display: flex; flex-direction: column; justify-content: space-between;
}
.post-item::before {
    content: ''; position: absolute; left: 0; top: 14px; bottom: 14px;
    width: 4px; background: rgba(0, 168, 255, 0.6); border-radius: 2px;
}
.post-item:hover { background: var(--card-bg, rgba(255, 255, 255, 0.25)); }
.post-header { display: flex; align-items: center; flex-wrap: wrap; margin-bottom: 8px; }
.post-author {
    font-size: 1rem; color: var(--text-secondary, #555); font-weight: 500;
    display: flex; align-items: center; gap: 6px;
}
.post-content {
    font-size: 1.2rem; color: var(--text-primary, #444); line-height: 1.5;
    white-space: pre-wrap; word-break: break-word; padding-left: 0;
    flex: 1; overflow: hidden; text-overflow: ellipsis;
    display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical;
}
.post-footer {
    display: flex; align-items: center; justify-content: space-between; margin-top: 8px;
}
.post-time { font-size: 0.85rem; color: var(--text-secondary, #999); display: flex; align-items: center; gap: 4px; }
.post-meta { display: flex; align-items: center; gap: 16px; }
.meta-item { font-size: 0.85rem; color: var(--text-secondary, #999); display: flex; align-items: center; gap: 4px; }
.loading, .no-posts, .error { color: var(--text-secondary, #888); font-size: 1rem; }
.error { color: #d32f2f; }
.no-posts { padding: 40px 20px; }
#no-more-tip { text-align: center; padding: 20px 0; color: var(--text-secondary, #999); font-size: 0.9rem; }
@media (max-width: 768px) {
    .fixed-tab-nav { top: 60px; }
    .tab-nav-wrapper { height: 55px; padding-left: 15px !important; padding-right: 15px !important; gap: 8px; }
    .tab-item { flex: 1; max-width: 90px; font-size: 0.9rem; padding: 8px 12px; }
    .fixed-status-container { top: 115px; bottom: 40px; padding-left: 0 !important; }
    .post-item { padding: 12px 16px 12px 16px; height: 120px; }
    .post-item::before { top: 12px; bottom: 12px; width: 3px; }
    .post-header { margin-bottom: 6px; }
    .post-author { font-size: 0.95rem; }
    .post-content { font-size: 1.05rem; -webkit-line-clamp: 2; }
    .post-footer { margin-top: 6px; }
    .post-time { font-size: 0.75rem; }
    .post-meta { gap: 12px; }
    .meta-item { font-size: 0.75rem; }
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabItems = document.querySelectorAll('.tab-item');
    tabItems.forEach(tab => {
        tab.addEventListener('click', function() {
            tabItems.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const type = this.getAttribute('data-type');
            if (window.refreshPostsList) window.refreshPostsList(type);
        });
    });
});
</script>
