<?php ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>关于 - 孝泉师范学校学生社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal; 
            font-style: normal; 
            font-display: swap;
        }
    </style>
    <style>
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #333;
            --text-secondary: #666;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --accent-hover: #48127a;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow-color: rgba(90, 24, 154, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
            --scrollbar-thumb: rgba(90, 24, 154, 0.3);
            --scrollbar-track: transparent;
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #e0e0e0;
            --text-secondary: #aaa;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --accent-hover: #9966cc;
            --glass-bg: rgba(30, 30, 60, 0.85);
            --glass-border: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --card-bg: rgba(30, 30, 60, 0.6);
            --scrollbar-thumb: rgba(187, 134, 252, 0.3);
            --scrollbar-track: transparent;
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #2e7d32;
            --text-secondary: #558b2f;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --accent-hover: #1b5e20;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.4);
            --shadow-color: rgba(46, 125, 50, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
            --scrollbar-thumb: rgba(46, 125, 50, 0.3);
            --scrollbar-track: transparent;
        }
        * { 
            -webkit-tap-highlight-color: transparent; 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif; 
        }
        html, body { 
            width: 100vw; 
            height: 100vh; 
            overflow: hidden; 
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%); 
            background-attachment: fixed; 
            color: var(--text-primary); 
        }
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: var(--scrollbar-track);
            border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb {
            background: var(--scrollbar-thumb);
            border-radius: 3px;
            transition: background 0.3s ease;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent);
        }
        .glass { 
            background: var(--glass-bg); 
            backdrop-filter: blur(10px) saturate(180%); 
            -webkit-backdrop-filter: blur(10px) saturate(180%); 
            border-radius: 16px; 
            border: 1px solid var(--glass-border); 
            box-shadow: 0 8px 32px var(--shadow-color); 
        }
        .full-page-container { 
            width: 100%; 
            height: 100vh; 
            display: flex; 
            flex-direction: column; 
            overflow: hidden; 
        }
        .top-nav { 
            width: 100%; 
            height: 60px; 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            padding: 0 20px; 
            background: var(--glass-bg); 
            backdrop-filter: blur(12px) saturate(180%); 
            border-bottom: 1px solid var(--glass-border); 
            flex-shrink: 0; 
            z-index: 10;
        }
        .back-btn { 
            width: 38px; 
            height: 38px; 
            border-radius: 8px; 
            background: var(--accent-light); 
            border: none; 
            color: var(--accent); 
            font-size: 18px; 
            cursor: pointer; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            transition: all 0.3s ease; 
        }
        .back-btn:hover { 
            background: var(--accent); 
            color: white; 
            transform: translateX(-2px);
        }
        .back-btn:active {
            transform: scale(0.95);
        }
        .nav-title { 
            font-size: 1.2rem; 
            font-weight: 600; 
            color: var(--text-primary); 
        }
        .nav-placeholder { 
            width: 38px; 
        }
        .main-content { 
            flex: 1; 
            width: 100%; 
            padding: 20px; 
            display: flex; 
            flex-direction: column; 
            gap: 15px; 
            overflow: hidden; 
        }
        .dev-card { 
            width: 100%; 
            padding: 20px; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            gap: 12px; 
            flex-shrink: 0; 
        }
        .avatar-box { 
            width: 90px; 
            height: 90px; 
            border-radius: 50%; 
            overflow: hidden; 
            border: 3px solid #fff; 
            box-shadow: 0 4px 15px var(--shadow-color); 
        }
        .avatar-box img { 
            width: 100%; 
            height: 100%; 
            object-fit: cover; 
        }
        .dev-name { 
            font-size: 1.3rem; 
            font-weight: 600; 
            color: var(--accent); 
        }
        .dev-desc { 
            font-size: 0.95rem; 
            color: var(--text-secondary); 
            text-align: center; 
        }
        .website-btn {
            margin-top: 4px;
            padding: 8px 18px;
            border-radius: 8px;
            background: var(--accent);
            border: none;
            color: #fff;
            font-size: 0.9rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .website-btn:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px var(--shadow-color);
        }
        .website-btn:active {
            transform: scale(0.98);
        }
        .collapse-wrapper { 
            width: 100%; 
            display: flex; 
            flex-direction: column; 
            gap: 12px; 
            flex-shrink: 1; 
            overflow: hidden; 
        }
        .collapse-item { 
            width: 100%; 
            border-radius: 12px; 
            overflow: hidden; 
            flex-shrink: 0; 
        }
        .collapse-header { 
            width: 100%; 
            padding: 15px 20px; 
            background: var(--accent-light); 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            cursor: pointer; 
            transition: all 0.3s ease; 
        }
        .collapse-header:hover {
            filter: brightness(1.05);
        }
        .collapse-title { 
            font-size: 1.05rem; 
            font-weight: 600; 
            color: var(--accent); 
            display: flex; 
            align-items: center; 
            gap: 8px; 
        }
        .collapse-icon { 
            color: var(--accent); 
            transition: transform 0.3s ease; 
        }
        .collapse-item.active .collapse-icon { 
            transform: rotate(180deg); 
        }
        .collapse-content { 
            max-height: 0; 
            overflow: hidden; 
            transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
            background: var(--card-bg); 
        }
        .collapse-item.active .collapse-content { 
            max-height: 320px; 
            overflow-y: auto; 
        }
        .content-inner { 
            padding: 15px 20px; 
            line-height: 1.7; 
            color: var(--text-primary); 
            font-size: 0.95rem; 
        }
        .content-inner p { 
            margin-bottom: 10px; 
        }
        .content-inner p:last-child { 
            margin-bottom: 0; 
        }
        .content-inner a {
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .content-inner a:hover {
            color: var(--accent-hover);
            text-decoration: underline;
        }
        .page-footer { 
            width: 100%; 
            padding: 10px 20px; 
            text-align: center; 
            color: var(--text-secondary); 
            font-size: 0.75rem; 
            background: var(--glass-bg); 
            backdrop-filter: blur(10px); 
            border-top: 1px solid var(--glass-border); 
            flex-shrink: 0; 
        }
        .page-footer a {
            color: var(--accent);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .page-footer a:hover {
            color: var(--accent-hover);
        }
        @media (max-width: 768px) {
            .top-nav { 
                height: 55px; 
                padding: 0 15px; 
            }
            .back-btn { 
                width: 34px; 
                height: 34px; 
                font-size: 16px; 
            }
            .nav-placeholder { 
                width: 34px; 
            }
            .main-content { 
                padding: 15px; 
                gap: 12px; 
            }
            .dev-card { 
                padding: 15px; 
            }
            .avatar-box { 
                width: 75px; 
                height: 75px; 
            }
            .dev-name { 
                font-size: 1.15rem; 
            }
            .dev-desc { 
                font-size: 0.85rem; 
            }
            .website-btn {
                padding: 7px 16px;
                font-size: 0.85rem;
            }
            .collapse-header { 
                padding: 12px 15px; 
            }
            .content-inner { 
                padding: 12px 15px; 
                font-size: 0.9rem; 
            }
            .collapse-item.active .collapse-content { 
                max-height: 240px; 
            }
        }
    </style>
</head>
<body>
    <div class="full-page-container">
        <nav class="top-nav">
            <button class="back-btn" id="backBtn"><i class="fas fa-arrow-left"></i></button>
            <div class="nav-title">关于</div>
            <div class="nav-placeholder"></div>
        </nav>
        <main class="main-content">
            <div class="dev-card glass">
                <div class="avatar-box"><img src="2.png" alt="开发者头像"></div>
                <div class="dev-name">毕加昊、优优</div>
                <div class="dev-desc">2024级9班 ｜ 独立开发者</div>
                <a href="https://www.毕加昊.top" target="_blank" rel="noopener noreferrer" class="website-btn">
                    <i class="fas fa-globe"></i>
                    访问个人官网 www.毕加昊.top
                </a>
            </div>
            <div class="collapse-wrapper">
                <div class="collapse-item glass" id="devCollapse">
                    <div class="collapse-header">
                        <div class="collapse-title"><i class="fas fa-user-circle"></i> 关于开发者</div>
                        <i class="fas fa-chevron-down collapse-icon"></i>
                    </div>
                    <div class="collapse-content">
                        <div class="content-inner">
                            <p>您好！我是本校园社区的开发者毕加昊，专注于为孝泉师范学校的同学们打造便捷、友好的校园线上交流平台。</p>
                            <p>开发初衷是希望能为同学们提供一个自由交流、信息共享、互帮互助的校园专属空间，解决校园内信息分散、交流不便的问题。</p>
                            <p>我的个人主页：<a href="https://www.毕加昊.top" target="_blank" rel="noopener noreferrer">www.毕加昊.top</a>，欢迎访问了解更多我的开发作品与技术动态。</p>
                            <p>如果你有任何功能建议、问题反馈，或是想一起完善这个项目，都可以通过校园内渠道或个人官网联系我。</p>
                            <p>感谢每一位同学的支持与包容，我会持续优化项目，给大家带来更好的使用体验。</p>
                        </div>
                    </div>
                </div>
                <div class="collapse-item glass" id="projectCollapse">
                    <div class="collapse-header">
                        <div class="collapse-title"><i class="fas fa-code"></i> 关于本项目</div>
                        <i class="fas fa-chevron-down collapse-icon"></i>
                    </div>
                    <div class="collapse-content">
                        <div class="content-inner">
                            <p>项目名称：孝泉师范学校学生社区</p>
                            <p>项目定位：校园专属的匿名/实名交流社区，聚焦校园生活、信息分享、同学互助。</p>
                            <p>核心功能：最新动态发布、热门内容排行、曝光挂人专区、帖子点赞评论、图片上传分享，后续会持续上线更多校园实用功能。</p>
                            <p>技术说明：项目前端采用HTML+CSS+JavaScript，后端采用原生PHP开发，无第三方框架，轻量高效。</p>
                            <p>温馨提示：本社区仅用于校园内正常交流，请大家遵守校规校纪与法律法规，文明发言，理性交流。</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <footer class="page-footer">
            © 2026 孝泉师范学校学生社区 版权所有 | 开发者 <a href="https://www.毕加昊.top" target="_blank" rel="noopener noreferrer">毕加昊</a>
        </footer>
    </div>
    <script>
        (function() { 
            try { 
                const s = JSON.parse(localStorage.getItem('community_theme')); 
                if (s) { 
                    if (s.name==='custom'&&s.vars) {
                        Object.entries(s.vars).forEach(([k,v])=>document.documentElement.style.setProperty(k,v)); 
                    } else if (s.name&&s.name!=='light') {
                        document.documentElement.setAttribute('data-theme',s.name); 
                    } 
                } 
            } catch(e){
                console.error('主题加载失败', e);
            } 
        })();
        document.getElementById('backBtn').addEventListener('click', () => { 
            window.location.href = 'index.php'; 
        });
        document.querySelectorAll('.collapse-item').forEach(item => {
            const header = item.querySelector('.collapse-header');
            header.addEventListener('click', () => { 
                item.classList.toggle('active'); 
            });
        });
    </script>
</body>
</html>
