<?php
$dataFile = 'data/posts.txt';
$postId = $_GET['id'] ?? '';
$targetPost = null;
if (!empty($postId) && file_exists($dataFile) && filesize($dataFile) > 0) {
    $lines = file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $post = json_decode($line, true);
        if ($post && $post['id'] === $postId) {
            $targetPost = $post;
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $targetPost ? '帖子详情' : '帖子不存在'; ?> - 社区广场</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal; font-style: normal; font-display: swap;
        }
    </style>
    <style>
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #333;
            --text-secondary: #666;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow-color: rgba(90, 24, 154, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #e0e0e0;
            --text-secondary: #aaa;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --glass-bg: rgba(30, 30, 60, 0.85);
            --glass-border: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --card-bg: rgba(30, 30, 60, 0.6);
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #2e7d32;
            --text-secondary: #558b2f;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.4);
            --shadow-color: rgba(46, 125, 50, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        * {
            -webkit-tap-highlight-color: transparent;
            margin: 0; padding: 0; box-sizing: border-box;
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif;
        }
        html, body { width: 100%; min-height: 100vh; overflow-x: hidden; }
        body {
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            background-attachment: fixed; color: var(--text-primary);
        }
        .full-screen-container { width: 100%; min-height: 100vh; padding: 0; margin: 0; }
        .post-detail-wrapper {
            width: 100%; padding: 20px 20px 30px;
            background: var(--glass-bg);
            min-height: 100vh;
        }
        .post-header {
            width: 100%; display: flex; flex-wrap: wrap;
            align-items: center; gap: 15px;
            margin-bottom: 10px; padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        .post-author {
            display: flex; align-items: center; gap: 8px;
            font-size: 1.2rem; font-weight: 600; color: var(--text-primary);
        }
        .post-meta {
            margin-left: auto; display: flex; align-items: center;
            gap: 20px; color: var(--text-secondary); font-size: 0.9rem;
        }
        .post-content {
            width: 100%; font-size: 1.3rem; line-height: 1.8;
            color: var(--text-primary); white-space: pre-wrap;
            word-break: break-word; margin-bottom: 25px; margin-top: 0; padding: 0;
        }
        .post-image { width: 100%; max-width: 600px; margin: 0 auto 30px; border-radius: 8px; overflow: hidden; }
        .post-image img { width: 100%; height: auto; max-height: 50vh; object-fit: contain; display: block; cursor: zoom-in; transition: transform 0.3s ease; margin: 0 auto; }
        .post-image img:hover { transform: scale(1.02); }
        .interaction-bar {
            width: 100%; display: flex; align-items: center;
            gap: 30px; padding: 20px 0;
            border-top: 1px solid var(--glass-border);
            border-bottom: 1px solid var(--glass-border); margin-bottom: 30px;
        }
        .like-btn {
            display: flex; align-items: center; gap: 8px;
            padding: 10px 20px; background: var(--accent-light);
            border: none; border-radius: 30px; font-size: 1rem;
            color: var(--text-secondary); cursor: pointer; transition: all 0.3s ease;
        }
        .like-btn:hover { background: var(--accent-light); transform: scale(1.05); }
        .like-btn.active { background: linear-gradient(135deg, var(--accent), #7b2cbf); color: white; }
        .like-btn.active i { animation: heartBeat 0.5s ease; }
        .comment-count { display: flex; align-items: center; gap: 8px; font-size: 1rem; color: var(--text-secondary); }
        .comment-fold-wrapper { width: 100%; margin-bottom: 30px; }
        .comment-toggle-btn {
            width: 100%; padding: 12px 20px;
            background: var(--accent-light);
            border: 1px solid var(--glass-border);
            border-radius: 8px; font-size: 1rem;
            color: var(--accent); cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            gap: 8px; transition: all 0.3s ease;
        }
        .comment-toggle-btn:hover { border-color: var(--accent); }
        .comment-form-wrapper { max-height: 0; overflow: hidden; transition: max-height 0.4s ease, opacity 0.4s ease; opacity: 0; }
        .comment-form-wrapper.show { max-height: 600px; opacity: 1; margin-top: 20px; }
        .comment-section { width: 100%; }
        .comment-section h3 { font-size: 1.2rem; color: var(--text-primary); margin-bottom: 20px; }
        .comment-form { width: 100%; }
        .comment-form-row { display: flex; gap: 15px; margin-bottom: 15px; }
        .comment-form-group { flex: 1; }
        .comment-form input, .comment-form textarea {
            width: 100%; padding: 12px 16px;
            border: 1px solid var(--glass-border);
            border-radius: 8px; font-size: 0.95rem;
            background: var(--card-bg); color: var(--text-primary);
        }
        .comment-form textarea { min-height: 100px; resize: none; margin-bottom: 15px; }
        .comment-form input:focus, .comment-form textarea:focus { outline: none; border-color: var(--accent); }
        .comment-submit-btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, var(--accent), #7b2cbf);
            color: white; border: none; border-radius: 8px;
            font-size: 1rem; cursor: pointer; transition: all 0.3s ease;
        }
        .comment-submit-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 15px var(--shadow-color); }
        .comment-submit-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        .form-msg { margin-top: 10px; font-size: 0.9rem; }
        .form-msg.error { color: #c62828; }
        .form-msg.success { color: #2e7d32; }
        .comment-list { width: 100%; display: flex; flex-direction: column; gap: 20px; }
        .comment-item { width: 100%; padding: 15px 0; border-bottom: 1px solid var(--glass-border); }
        .comment-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
        .comment-author { font-weight: 600; color: var(--text-primary); display: flex; align-items: center; gap: 6px; }
        .comment-time { font-size: 0.85rem; color: var(--text-secondary); margin-left: auto; }
        .comment-content { font-size: 1rem; line-height: 1.6; color: var(--text-primary); white-space: pre-wrap; word-break: break-word; }
        .empty-comment { text-align: center; padding: 40px 0; color: var(--text-secondary); }
        .empty-state { width: 100%; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; }
        .empty-state i { font-size: 4rem; color: #ccc; margin-bottom: 20px; }
        .empty-state h3 { color: var(--text-secondary); margin-bottom: 15px; }
        @keyframes heartBeat { 0% { transform: scale(1); } 50% { transform: scale(1.3); } 100% { transform: scale(1); } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .fade-in { animation: fadeInUp 0.3s ease; }
        @media (max-width: 768px) {
            .post-detail-wrapper { padding: 15px 15px 20px; }
            .post-header { gap: 10px; margin-bottom: 8px; }
            .post-meta { width: 100%; margin-left: 0; justify-content: space-between; }
            .post-content { font-size: 1.15rem; }
            .interaction-bar { gap: 20px; }
            .comment-form-row { flex-direction: column; gap: 10px; }
            .post-image { max-width: 100%; }
            .post-image img { max-height: 40vh; }
        }
    </style>
</head>
<body>
    <?php if ($targetPost): ?>
        <div class="full-screen-container">
            <div class="post-detail-wrapper">
                <div class="post-header">
                    <span class="post-author"><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($targetPost['author']); ?></span>
                    <div class="post-meta">
                        <span><i class="far fa-clock"></i> <?php echo date('Y-m-d H:i:s', $targetPost['timestamp']); ?></span>
                        <span><i class="far fa-eye"></i> <span id="viewCount"><?php echo $targetPost['view_count'] ?? 0; ?></span> 次浏览</span>
                    </div>
                </div>
                <div class="post-content"><?php echo htmlspecialchars($targetPost['content']); ?></div>
                <?php if (!empty($targetPost['image'])): ?>
                    <div class="post-image"><img src="<?php echo htmlspecialchars($targetPost['image']); ?>" alt="帖子配图" onclick="window.open(this.src)"></div>
                <?php endif; ?>
                <div class="interaction-bar">
                    <button class="like-btn" id="likeBtn" data-post-id="<?php echo $targetPost['id']; ?>">
                        <i class="fas fa-heart"></i> <span id="likeCount"><?php echo $targetPost['like_count'] ?? 0; ?></span> 赞
                    </button>
                    <div class="comment-count"><i class="far fa-comment"></i> <span id="commentCount"><?php echo $targetPost['comment_count'] ?? 0; ?></span> 条评论</div>
                </div>
                <div class="comment-section">
                    <div class="comment-fold-wrapper">
                        <button class="comment-toggle-btn" id="commentToggleBtn"><i class="fas fa-pen"></i><span>发表评论</span></button>
                        <div class="comment-form-wrapper" id="commentFormWrapper">
                            <form class="comment-form" id="commentForm">
                                <input type="hidden" name="post_id" value="<?php echo $targetPost['id']; ?>">
                                <div class="comment-form-row">
                                    <div class="comment-form-group"><input type="text" name="author" placeholder="你的昵称（不填则匿名）" maxlength="5"></div>
                                </div>
                                <textarea name="content" placeholder="写下你的评论..." required maxlength="30"></textarea>
                                <button type="submit" class="comment-submit-btn">发布评论</button>
                                <div class="form-msg" id="formMsg"></div>
                            </form>
                        </div>
                    </div>
                    <h3>全部评论 <span id="commentTotal">(<?php echo $targetPost['comment_count'] ?? 0; ?>)</span></h3>
                    <div class="comment-list" id="commentList"><div class="empty-comment">正在加载评论...</div></div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-file-exclamation"></i>
            <h3>帖子不存在或已被删除</h3>
            <a href="index.php" style="margin:0 auto;padding:10px 20px;background:var(--accent,#5a189a);border:none;border-radius:8px;color:white;font-size:1rem;cursor:pointer;text-decoration:none;">返回首页</a>
        </div>
    <?php endif; ?>
    <script>
        (function() { try { const s = JSON.parse(localStorage.getItem('community_theme')); if (s) { if (s.name==='custom'&&s.vars) Object.entries(s.vars).forEach(([k,v])=>document.documentElement.style.setProperty(k,v)); else if (s.name&&s.name!=='light') document.documentElement.setAttribute('data-theme',s.name); } } catch(e){} })();
        const postId = '<?php echo $targetPost ? $targetPost["id"] : ""; ?>';
        const POLL_INTERVAL = 10000;
        let pollTimer = null;
        if (postId) {
            fetch(`api.php?action=increment_view&post_id=${postId}`)
            .then(r => r.json())
            .then(data => {
                if (data.success && data.post) {
                    document.getElementById('viewCount').textContent = data.post.view_count;
                }
            }).catch(() => {});
        }
        const commentToggleBtn = document.getElementById('commentToggleBtn');
        const commentFormWrapper = document.getElementById('commentFormWrapper');
        if (commentToggleBtn && commentFormWrapper) {
            commentToggleBtn.addEventListener('click', function() {
                const isOpen = commentFormWrapper.classList.contains('show');
                if (isOpen) { commentFormWrapper.classList.remove('show'); this.innerHTML = '<i class="fas fa-pen"></i><span>发表评论</span>'; }
                else { commentFormWrapper.classList.add('show'); this.innerHTML = '<i class="fas fa-chevron-up"></i><span>收起评论框</span>'; const t=commentFormWrapper.querySelector('textarea'); if(t) t.focus(); }
            });
        }
        async function pollDataUpdate() {
            if (!postId) return;
            try {
                const postRes = await fetch(`api.php?action=get_post&post_id=${postId}`);
                const postData = await postRes.json();
                if (postData.success) {
                    const { post } = postData;
                    const vc = document.getElementById('viewCount');
                    const lc = document.getElementById('likeCount');
                    const cc = document.getElementById('commentCount');
                    const ct = document.getElementById('commentTotal');
                    if (vc && vc.textContent != post.view_count) vc.textContent = post.view_count;
                    if (lc && lc.textContent != post.like_count) lc.textContent = post.like_count;
                    if (cc && cc.textContent != post.comment_count) cc.textContent = post.comment_count;
                    if (ct) ct.textContent = `(${post.comment_count})`;
                }
                await loadComments(false);
            } catch (err) { console.error('轮询更新失败', err); }
        }
        async function initLikeStatus() {
            if (!postId) return;
            try {
                const res = await fetch(`api.php?action=check_like&post_id=${postId}`);
                const data = await res.json();
                if (data.success && data.is_liked) document.getElementById('likeBtn').classList.add('active');
            } catch (err) {}
        }
        const likeBtn = document.getElementById('likeBtn');
        if (likeBtn) {
            likeBtn.addEventListener('click', function() {
                if (this.classList.contains('active')) return;
                likeBtn.disabled = true;
                fetch('api.php?action=like', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id:postId}) })
                .then(r => r.json())
                .then(data => { if (data.success) likeBtn.classList.add('active'); else { alert(data.message); if (data.message.includes('已经点赞过')) likeBtn.classList.add('active'); } })
                .catch(() => alert('点赞失败'))
                .finally(() => { likeBtn.disabled = false; });
            });
        }
        const commentForm = document.getElementById('commentForm');
        const commentList = document.getElementById('commentList');
        const formMsg = document.getElementById('formMsg');
        async function loadComments(showLoading = true) {
            if (!postId) return;
            try {
                const res = await fetch(`api.php?action=get_comments&post_id=${postId}`);
                const data = await res.json();
                if (data.success) {
                    if (data.comments.length === 0) { if (showLoading) commentList.innerHTML = '<div class="empty-comment">暂无评论，快来抢沙发吧！</div>'; return; }
                    let html = '';
                    data.comments.forEach(c => {
                        const date = new Date(c.timestamp * 1000).toLocaleString('zh-CN');
                        html += `<div class="comment-item fade-in"><div class="comment-header"><span class="comment-author"><i class="fas fa-user-circle"></i> ${c.author}</span><span class="comment-time"><i class="far fa-clock"></i> ${date}</span></div><div class="comment-content">${c.content}</div></div>`;
                    });
                    commentList.innerHTML = html;
                }
            } catch (err) { if (showLoading) commentList.innerHTML = '<div class="empty-comment">评论加载失败</div>'; }
        }
        if (commentForm) {
            commentForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const submitBtn = this.querySelector('.comment-submit-btn');
                const formData = new FormData(this);
                const data = Object.fromEntries(formData.entries());
                if (!data.content.trim()) { formMsg.className = 'form-msg error'; formMsg.textContent = '评论内容不能为空'; return; }
                submitBtn.disabled = true; submitBtn.textContent = '发布中...';
                formMsg.className = 'form-msg'; formMsg.textContent = '';
                fetch('api.php?action=comment', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        formMsg.className = 'form-msg success'; formMsg.textContent = data.message;
                        commentForm.reset(); loadComments();
                        commentFormWrapper.classList.remove('show');
                        commentToggleBtn.innerHTML = '<i class="fas fa-pen"></i><span>发表评论</span>';
                        setTimeout(() => formMsg.textContent = '', 1500);
                    } else { formMsg.className = 'form-msg error'; formMsg.textContent = data.message; }
                })
                .catch(() => { formMsg.className = 'form-msg error'; formMsg.textContent = '发布失败'; })
                .finally(() => { submitBtn.disabled = false; submitBtn.textContent = '发布评论'; });
            });
        }
        document.addEventListener('DOMContentLoaded', function() {
            if (postId) { initLikeStatus(); loadComments(); pollTimer = setInterval(pollDataUpdate, POLL_INTERVAL); }
        });
        window.addEventListener('beforeunload', function() { if (pollTimer) clearInterval(pollTimer); });
    </script>
</body>
</html>
