<section class="post-form">
    <h2><i class="fas fa-feather-alt"></i> 投稿</h2>
    <form id="postForm" enctype="multipart/form-data">
        <div class="form-row">
            <div class="form-group">
                <label for="category">内容分类</label>
                <select id="category" name="category">
                    <option value="普通">普通日常</option>
                    <option value="挂人">曝光挂人</option>
                </select>
            </div>
            <div class="form-group">
                <label for="author">你的昵称</label>
                <input type="text" id="author" name="author" placeholder="不填则匿名"匿名用户"" maxlength="20">
            </div>
        </div>
        <div class="form-group">
            <label for="content">内容详情 <span class="required">*</span></label>
            <textarea id="content" name="content" rows="5" placeholder="在这里写下你想说的话..." required maxlength="50"></textarea>
            <div class="word-count" id="contentCount">0/50</div>
        </div>
        <div class="form-group">
            <label for="postImage">上传配图</label>
            <div class="image-upload-area">
                <input type="file" id="postImage" name="image" accept="image/*" hidden>
                <div class="upload-trigger" id="uploadTrigger">
                    <div class="upload-icon"><i class="fas fa-camera"></i></div>
                    <p>点击选择图片</p>
                    <span>支持jpg/png/gif/webp，最大2MB</span>
                </div>
                <div class="image-preview" id="imagePreview" style="display: none;">
                    <img id="previewImg" src="" alt="预览图">
                    <button type="button" class="remove-img-btn" id="removeImgBtn"><i class="fas fa-times"></i></button>
                </div>
            </div>
        </div>
        <button type="submit" class="submit-btn"><i class="fas fa-paper-plane"></i> 立即发布</button>
        <div id="formMsg" class="msg"></div>
    </form>
</section>
<style>
.post-form { padding: 10px; }
.post-form h2 {
    margin: 0 0 24px 0;
    background: linear-gradient(135deg, var(--accent, #5a189a), #7b2cbf);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    padding-bottom: 12px; border-bottom: 2px solid var(--accent-light, rgba(90, 24, 154, 0.1));
    display: flex; align-items: center; gap: 10px; font-size: 1.4rem; font-weight: 600;
}
.form-row { display: flex; gap: 15px; margin-bottom: 16px; }
.form-group { flex: 1; position: relative; }
.form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-secondary, #555); font-size: 0.95rem; }
.required { color: #c9184a; font-weight: 600; }
#postForm input, #postForm textarea, #postForm select {
    width: 100%; padding: 12px 16px;
    border: 1px solid var(--accent-light, rgba(90, 24, 154, 0.15));
    border-radius: 12px; font-size: 0.95rem;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    background: var(--card-bg, rgba(255, 255, 255, 0.6));
    backdrop-filter: blur(6px); box-sizing: border-box;
    color: var(--text-primary, #333);
}
#postForm textarea { resize: none; min-height: 120px; }
#postForm input:focus, #postForm textarea:focus, #postForm select:focus {
    outline: none; border-color: var(--accent, #5a189a);
    box-shadow: 0 0 0 4px var(--accent-light, rgba(90, 24, 154, 0.1));
    background: var(--glass-bg, rgba(255, 255, 255, 0.9));
    transform: translateY(-1px);
}
.word-count { text-align: right; font-size: 0.75rem; color: var(--text-secondary, #9e9e9e); margin-top: 6px; transition: color 0.2s; }
.word-count.overflow { color: #c9184a; font-weight: 600; }
.image-upload-area { width: 100%; position: relative; }
.upload-trigger {
    width: 100%; padding: 30px 20px;
    border: 2px dashed var(--accent-light, rgba(90, 24, 154, 0.25));
    border-radius: 12px; display: flex; flex-direction: column;
    align-items: center; justify-content: center; gap: 8px;
    cursor: pointer; transition: all 0.3s ease;
    background: var(--accent-light, rgba(90, 24, 154, 0.03));
}
.upload-trigger:hover { border-color: var(--accent, #5a189a); transform: scale(1.01); }
.upload-icon {
    width: 45px; height: 45px; border-radius: 50%;
    background: linear-gradient(135deg, var(--accent, #5a189a), #7b2cbf);
    display: flex; align-items: center; justify-content: center;
    color: white; font-size: 1.2rem; margin-bottom: 5px;
}
.upload-trigger p { margin: 0; font-size: 1rem; color: var(--text-secondary, #555); font-weight: 500; }
.upload-trigger span { font-size: 0.75rem; color: var(--text-secondary, #999); }
.image-preview {
    position: relative; width: 100%; margin-top: 10px;
    border-radius: 12px; overflow: hidden;
    border: 1px solid var(--accent-light, rgba(90, 24, 154, 0.15));
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}
.image-preview img { width: 100%; height: auto; max-height: 320px; object-fit: contain; display: block; background: #f8f8f8; }
.remove-img-btn {
    position: absolute; top: 10px; right: 10px;
    width: 34px; height: 34px; border-radius: 50%;
    background: rgba(0, 0, 0, 0.65); color: white; border: none;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; transition: all 0.2s ease; backdrop-filter: blur(4px);
}
.remove-img-btn:hover { background: #c9184a; transform: scale(1.1); }
.msg { margin-top: 15px; padding: 12px 16px; border-radius: 10px; font-size: 0.9rem; animation: fadeIn 0.3s ease; }
.msg.error { background: linear-gradient(90deg, #ffebee, #fce4ec); color: #c62828; border-left: 4px solid #c62828; }
.msg.success { background: linear-gradient(90deg, #e8f5e9, #e0f7fa); color: #2e7d32; border-left: 4px solid #2e7d32; }
.submit-btn {
    background: linear-gradient(135deg, var(--accent, #5a189a), #7b2cbf, #9d4edd);
    background-size: 200% 100%; color: white; border: none;
    padding: 14px 20px; border-radius: 12px; font-size: 1.05rem;
    font-weight: 600; cursor: pointer; width: 100%;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex; justify-content: center; align-items: center;
    gap: 10px; margin-top: 10px;
    box-shadow: 0 4px 15px rgba(90, 24, 154, 0.25);
}
.submit-btn:hover { background-position: 100% 0; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(90, 24, 154, 0.35); }
.submit-btn:active { transform: translateY(0); }
.submit-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none !important; background-position: 0 0; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@media (max-width: 768px) {
    .post-form { padding: 5px; }
    .post-form h2 { font-size: 1.2rem; margin-bottom: 20px; padding-bottom: 10px; }
    .form-row { flex-direction: column; gap: 12px; margin-bottom: 12px; }
    .form-group { margin-bottom: 12px; }
    #postForm input, #postForm textarea, #postForm select { padding: 10px 14px !important; font-size: 0.9rem !important; }
    .upload-trigger { padding: 20px 15px; }
    .upload-icon { width: 40px; height: 40px; font-size: 1rem; }
    .upload-trigger p { font-size: 0.9rem; }
    .upload-trigger span { font-size: 0.7rem; }
    .submit-btn { padding: 12px 16px !important; font-size: 1rem !important; }
}
</style>
<script>
const DRAFT_KEY = 'community_post_draft';
const postForm = document.getElementById('postForm');
const formMsg = document.getElementById('formMsg');
const authorInput = document.getElementById('author');
const contentInput = document.getElementById('content');
const categorySelect = document.getElementById('category');
const contentCount = document.getElementById('contentCount');
const postImageInput = document.getElementById('postImage');
const uploadTrigger = document.getElementById('uploadTrigger');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const removeImgBtn = document.getElementById('removeImgBtn');
const sensitiveWords = ['ai', 'AI', '垃圾', '乐子'];
function updateWordCount() {
    const len = contentInput.value.length;
    contentCount.textContent = `${len}/50`;
    contentCount.classList.toggle('overflow', len > 50);
}
function saveDraft() {
    localStorage.setItem(DRAFT_KEY, JSON.stringify({ category: categorySelect.value, author: authorInput.value, content: contentInput.value }));
}
function restoreDraft() {
    try {
        const draft = JSON.parse(localStorage.getItem(DRAFT_KEY));
        if (draft) { categorySelect.value = draft.category || '普通'; authorInput.value = draft.author || ''; contentInput.value = draft.content || ''; updateWordCount(); }
    } catch(e) { localStorage.removeItem(DRAFT_KEY); }
}
function checkSensitiveWords(text) { return sensitiveWords.some(w => text.toLowerCase().includes(w.toLowerCase())); }
uploadTrigger.addEventListener('click', () => postImageInput.click());
postImageInput.addEventListener('change', (e) => {
    const file = e.target.files[0]; if (!file) return;
    if (file.size > 5 * 1024 * 1024) { formMsg.className = 'msg error'; formMsg.innerHTML = '图片大小不能超过2MB'; postImageInput.value = ''; return; }
    if (!file.type.startsWith('image/')) { formMsg.className = 'msg error'; formMsg.innerHTML = '仅支持图片格式'; postImageInput.value = ''; return; }
    const reader = new FileReader();
    reader.onload = (ev) => { previewImg.src = ev.target.result; imagePreview.style.display = 'block'; uploadTrigger.style.display = 'none'; formMsg.className = 'msg'; formMsg.innerHTML = ''; };
    reader.readAsDataURL(file);
});
removeImgBtn.addEventListener('click', () => { postImageInput.value = ''; previewImg.src = ''; imagePreview.style.display = 'none'; uploadTrigger.style.display = 'flex'; });
authorInput.addEventListener('input', saveDraft);
contentInput.addEventListener('input', () => { updateWordCount(); saveDraft(); });
categorySelect.addEventListener('change', saveDraft);
postForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const submitBtn = this.querySelector('.submit-btn');
    const originalText = submitBtn.innerHTML;
    const contentValue = contentInput.value.trim();
    if (!contentValue) { formMsg.className = 'msg error'; formMsg.innerHTML = '发布内容不能为空'; return; }
    if (contentValue.length > 50) { formMsg.className = 'msg error'; formMsg.innerHTML = '输入内容超出字数限制'; return; }
    if (checkSensitiveWords(contentValue)) { formMsg.className = 'msg error'; formMsg.innerHTML = '内容包含违规信息'; return; }
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 发布中...'; submitBtn.disabled = true;
    formMsg.className = 'msg'; formMsg.innerHTML = '';
    const formData = new FormData(this);
    fetch('api.php?action=post', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            formMsg.className = 'msg success'; formMsg.innerHTML = data.message;
            this.reset(); localStorage.removeItem(DRAFT_KEY);
            imagePreview.style.display = 'none'; uploadTrigger.style.display = 'flex'; previewImg.src = '';
            updateWordCount();
            if (window.refreshPostsList) {
                const activeTab = document.querySelector('.tab-item.active');
                window.refreshPostsList(activeTab ? activeTab.getAttribute('data-type') : 'latest');
            }
            setTimeout(() => {
                const publishModal = document.getElementById('publishModal');
                if (publishModal) { publishModal.classList.remove('show'); document.body.style.overflow = 'auto'; }
                formMsg.innerHTML = '';
            }, 800);
        } else { formMsg.className = 'msg error'; formMsg.innerHTML = data.message; }
    })
    .catch(() => { formMsg.className = 'msg error'; formMsg.innerHTML = '发布失败，请检查网络'; })
    .finally(() => { submitBtn.innerHTML = originalText; submitBtn.disabled = false; });
});
document.addEventListener('DOMContentLoaded', function() { restoreDraft(); updateWordCount(); });
</script>
