<?php
session_start();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>孝泉师范学校学生社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal; font-style: normal; font-display: swap;
        }
    </style>
    <style>
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #333;
            --text-secondary: #666;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow-color: rgba(90, 24, 154, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #e0e0e0;
            --text-secondary: #aaa;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --glass-bg: rgba(30, 30, 60, 0.85);
            --glass-border: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --card-bg: rgba(30, 30, 60, 0.6);
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #2e7d32;
            --text-secondary: #558b2f;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.4);
            --shadow-color: rgba(46, 125, 50, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
        }
        * {
            -webkit-tap-highlight-color: transparent;
            margin: 0; padding: 0; box-sizing: border-box;
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', sans-serif;
        }
        body {
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            color: var(--text-primary); min-height: 100vh;
            background-attachment: fixed;
            padding-top: 130px; padding-left: 260px; padding-bottom: 45px;
            transition: padding-left 0.3s ease;
        }
        body.sidebar-hidden { padding-left: 0; }
        body.scroll-locked { overflow: hidden !important; }
        body.content-scroll-locked { overflow: hidden !important; }
        .glass {
            background: var(--glass-bg);
            backdrop-filter: blur(10px) saturate(180%);
            -webkit-backdrop-filter: blur(10px) saturate(180%);
            border-radius: 16px;
            border: 1px solid var(--glass-border);
            box-shadow: 0 8px 32px var(--shadow-color);
        }
        .fixed-header {
            position: fixed; top: 0; left: 0; width: 100%; z-index: 1002;
            background: var(--glass-bg);
            backdrop-filter: blur(12px) saturate(180%);
            border-bottom: 2px solid var(--glass-border);
            box-shadow: 0 4px 20px var(--shadow-color);
            display: flex; justify-content: space-between; align-items: center;
            padding: 15px 20px; height: 70px;
        }
        .sidebar-toggle-btn, .user-btn {
            background: var(--accent-light); border: none; border-radius: 8px;
            width: 38px; height: 38px; display: flex; align-items: center;
            justify-content: center; color: var(--accent); font-size: 18px;
            cursor: pointer; transition: all 0.3s ease; flex-shrink: 0;
        }
        .sidebar-toggle-btn:hover, .user-btn:hover { background: var(--accent); color: white; }
        .logo { display: flex; align-items: center; justify-content: center; }
        .logo img { width: 40px; height: 40px; object-fit: contain; }
        .fixed-sidebar {
            position: fixed; top: 130px; left: 0; bottom: 0; width: 260px; z-index: 999;
            background: var(--glass-bg);
            backdrop-filter: blur(10px) saturate(180%);
            border-right: 1px solid var(--glass-border);
            box-shadow: 0 8px 32px var(--shadow-color);
            padding: 25px 15px; overflow-y: auto;
            transition: transform 0.3s ease;
        }
        .fixed-sidebar.hidden { transform: translateX(-100%); }
        .sidebar-menu { display: flex; flex-direction: column; gap: 10px; }
        .sidebar-title {
            font-size: 0.9rem; color: var(--text-secondary);
            padding: 0 15px; margin-bottom: 10px; font-weight: 600;
        }
        .sidebar-item {
            text-decoration: none; color: var(--text-secondary);
            padding: 12px 15px; border-radius: 12px; transition: all 0.3s ease;
            display: flex; align-items: center; gap: 12px; font-weight: 500;
        }
        .sidebar-item:hover, .sidebar-item.active {
            background-color: var(--accent-light); color: var(--accent);
        }
        .main-container {
            max-width: 1200px; margin: 0 auto; padding: 20px;
            min-height: calc(100vh - 175px); position: relative;
            transition: all 0.3s ease;
        }
        .main-container.dimmed::after {
            content: ''; position: fixed; top: 130px; left: 0; right: 0; bottom: 45px;
            background: rgba(0, 0, 0, 0.4); z-index: 990;
            pointer-events: auto; opacity: 1; transition: opacity 0.3s ease;
        }
        .publish-float-btn {
            position: fixed; bottom: 75px; right: 30px;
            width: 60px; height: 60px; border-radius: 50%;
            background: linear-gradient(135deg, rgba(90, 24, 154, 0.5), rgba(123, 44, 191, 0.5));
            color: white; border: none; display: flex; align-items: center;
            justify-content: center; font-size: 24px; cursor: pointer;
            z-index: 1001; box-shadow: 0 8px 25px rgba(90, 24, 154, 0.2);
            transition: all 0.3s ease;
        }
        .publish-float-btn:hover {
            transform: scale(1.1) rotate(90deg);
            background: linear-gradient(135deg, rgba(90, 24, 154, 0.85), rgba(123, 44, 191, 0.85));
            box-shadow: 0 10px 30px rgba(90, 24, 154, 0.35);
        }
        .publish-modal {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.45); backdrop-filter: blur(6px);
            z-index: 1003; display: none; align-items: center;
            justify-content: center; padding: 20px; animation: fadeIn 0.3s ease;
        }
        .publish-modal.show { display: flex; }
        .modal-content {
            width: 100%; max-width: 500px; max-height: 85vh;
            overflow-y: auto; animation: slideUp 0.3s ease;
        }
        .modal-close-btn {
            position: absolute; top: 15px; right: 15px;
            width: 36px; height: 36px; border-radius: 50%;
            background: var(--glass-bg); border: none;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; cursor: pointer; color: var(--text-primary);
            transition: all 0.2s ease;
        }
        .modal-close-btn:hover { background: var(--accent); color: white; }
        .glass-footer {
            position: fixed; bottom: 0; left: 0; width: 100%; z-index: 998;
            background: var(--glass-bg);
            backdrop-filter: blur(10px) saturate(180%);
            border-top: 1px solid var(--glass-border);
            box-shadow: 0 -4px 20px var(--shadow-color);
            padding: 6px 15px;
            font-size: 0.7rem;
            color: var(--text-secondary);
        }
        .footer-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: nowrap;
            gap: 10px;
        }
        .footer-core {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }
        .footer-extra {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 1;
            overflow: hidden;
            white-space: nowrap;
        }
        .footer-toggle {
            background: transparent;
            border: none;
            color: var(--accent);
            cursor: pointer;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 4px;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }
        .footer-toggle:hover {
            background: var(--accent-light);
        }
        .footer-icp a {
            color: var(--text-secondary);
            text-decoration: none;
            transition: color 0.2s ease;
        }
        .footer-icp a:hover {
            color: var(--accent);
        }
        .footer-item {
            display: flex;
            align-items: center;
            gap: 3px;
            white-space: nowrap;
        }
        .footer-extra.collapsed {
            display: none;
        }
        .pinned-modal {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.45); backdrop-filter: blur(6px);
            z-index: 1004; display: none;
            align-items: center; justify-content: center; padding: 20px;
        }
        .pinned-modal.show { display: flex; }
        .pinned-content {
            width: 100%; max-width: 480px; padding: 30px;
            position: relative; animation: slideUp 0.3s ease;
        }
        .pinned-title {
            font-size: 1.3rem; font-weight: 600; color: var(--text-primary);
            margin-bottom: 15px;
            text-align: center;
        }
        .pinned-body {
            font-size: 0.95rem; line-height: 1.7; color: var(--text-primary);
            white-space: pre-wrap; word-break: break-word;
            max-height: 50vh; overflow-y: auto;
            margin-bottom: 20px;
        }
        .pinned-btn-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            width: 100%;
        }
        .pinned-close-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, var(--accent), #7b2cbf);
            color: white; border: none; border-radius: 10px;
            font-size: 1rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s;
        }
        .pinned-close-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px var(--shadow-color); }
        .pinned-hide-btn {
            width: fit-content;
            margin: 0 auto;
            padding: 4px 8px;
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-size: 0.8rem;
            font-weight: 400;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: underline;
            text-underline-offset: 2px;
        }
        .pinned-hide-btn:hover {
            color: var(--accent);
            background: transparent;
        }
        .copy-tip {
            text-align: center;
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-top: 12px;
            opacity: 0.8;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes slideInLeft { from { transform: translateX(-30px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .slide-in { animation: slideInLeft 0.3s ease forwards; }
        .msg { margin-top: 15px; padding: 10px; border-radius: 8px; }
        .msg.error { background-color: #ffebee; color: #c62828; }
        .msg.success { background-color: #e8f5e9; color: #2e7d32; }
        @media (max-width: 768px) {
            body { padding-left: 0 !important; padding-top: 115px; padding-bottom: 40px; }
            .fixed-header { height: 60px; padding: 10px 15px; }
            .sidebar-toggle-btn, .user-btn { width: 34px; height: 34px; font-size: 16px; }
            .logo img { width: 32px; height: 32px; }
            .fixed-sidebar { top: 115px; transform: translateX(-100%); }
            .fixed-sidebar.show { transform: translateX(0); }
            .main-container { padding: 15px 10px; }
            .main-container.dimmed::after { top: 115px; bottom: 40px; }
            .publish-float-btn { bottom: 60px; right: 20px; width: 55px; height: 55px; font-size: 22px; }
            .glass-footer { padding: 4px 10px; font-size: 0.65rem; }
            .footer-wrapper { gap: 6px; }
            .footer-core { gap: 8px; }
            .footer-extra { gap: 8px; }
            .footer-extra {
                display: none;
            }
            .footer-extra.show {
                display: flex;
                flex-wrap: wrap;
                width: 100%;
                margin-top: 4px;
            }
            .footer-wrapper {
                flex-wrap: wrap;
            }
            .pinned-btn-group {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <header class="fixed-header">
        <button class="sidebar-toggle-btn" id="sidebarToggleBtn"><i class="fas fa-bars"></i></button>
        <div class="logo"><img src="1.png" alt="校徽"></div>
        <button class="user-btn" id="userBtn"><i class="fas fa-user"></i></button>
    </header>
    <aside class="fixed-sidebar">
        <div class="sidebar-menu">
            <p class="sidebar-title">社区导航</p>
            <a href="公告.php" class="sidebar-item"><i class="fas fa-bullhorn"></i><span>通知公告</span></a>
            <a href="暂未开发.php" class="sidebar-item"><i class="fas fa-calendar-alt"></i><span>课表查询</span></a>
            <a href="暂未开发.php" class="sidebar-item"><i class="fas fa-calendar"></i><span>校园日历</span></a>
            <p class="sidebar-title" style="margin-top: 30px;">设置</p>
            <a href="主题.php" class="sidebar-item"><i class="fas fa-palette"></i><span>主题设置</span></a>
            <a href="关于.php" class="sidebar-item"><i class="fas fa-info-circle"></i><span>关于开发</span></a>
            <a href="条款.php" class="sidebar-item"><i class="fas fa-file-contract"></i><span>免责条款</span></a>
        </div>
    </aside>
    <main class="main-container" id="mainContainer">
        <?php include 'posts.php'; ?>
    </main>
    <footer class="glass-footer">
        <div class="footer-wrapper">
            <div class="footer-core">
                <span class="footer-item" id="runtimeCount">
                    <i class="fas fa-heartbeat"></i> 社区已稳定运行0天0小时0分0秒
                </span>
                <span class="footer-icp">
                    <a href="https://icp.gov.moe/" target="_blank">萌ICP备20260121号</a>
                </span>
                <button class="footer-toggle" id="footerToggleBtn">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
            </div>
            <div class="footer-extra collapsed" id="footerExtra">
                <span class="footer-item" id="loadTime">
                    <i class="fas fa-bolt"></i> 加载耗时: <span>0</span>ms
                </span>
                <span class="footer-item" id="queryCount">
                    <i class="fas fa-database"></i> 共查询: <span>0</span>次
                </span>
            </div>
        </div>
    </footer>
    <button class="publish-float-btn" id="publishBtn"><i class="fas fa-plus"></i></button>
    <div class="publish-modal" id="publishModal">
        <div class="modal-content glass">
            <button class="modal-close-btn" id="closeModalBtn"><i class="fas fa-times"></i></button>
            <?php include 'publish.php'; ?>
        </div>
    </div>
    <div class="pinned-modal" id="pinnedModal">
        <div class="pinned-content glass">
            <div class="pinned-title" id="pinnedTitle"></div>
            <div class="pinned-body" id="pinnedBody"></div>
            <div class="pinned-btn-group">
                <button class="pinned-close-btn" id="pinnedDismissBtn">我知道了</button>
                <button class="pinned-hide-btn" id="pinnedHideBtn">24小时内不再显示</button>
            </div>
        </div>
    </div>
    <script>
        (function initTheme() {
            try {
                const saved = localStorage.getItem('community_theme');
                if (saved) {
                    const s = JSON.parse(saved);
                    if (s.name === 'custom' && s.vars) {
                        Object.entries(s.vars).forEach(([k, v])=>document.documentElement.style.setProperty(k, v));
                    } else if (s.name && s.name !== 'light') {
                        document.documentElement.setAttribute('data-theme', s.name);
                    }
                }
            } catch(e){}
        })();
        window.paginationState = { currentPage: 1, pageSize: 10, currentType: 'latest', isLoading: false, hasMore: true };
        window.queryCount = 0;
        const originalFetch = window.fetch;
        window.fetch = function(...args) {
            const url = args[0] || '';
            if (url.includes('api.php')) {
                window.queryCount++;
                document.querySelector('#queryCount span').textContent = window.queryCount;
            }
            return originalFetch.apply(this, args);
        };
        const publishBtn = document.getElementById('publishBtn');
        const publishModal = document.getElementById('publishModal');
        const closeModalBtn = document.getElementById('closeModalBtn');
        publishBtn.addEventListener('click', () => { publishModal.classList.add('show'); document.body.style.overflow = 'hidden'; });
        closeModalBtn.addEventListener('click', () => { publishModal.classList.remove('show'); if (!document.body.classList.contains('scroll-locked') && !document.body.classList.contains('content-scroll-locked')) document.body.style.overflow = 'auto'; });
        publishModal.addEventListener('click', (e) => { if (e.target === publishModal) { publishModal.classList.remove('show'); if (!document.body.classList.contains('scroll-locked') && !document.body.classList.contains('content-scroll-locked')) document.body.style.overflow = 'auto'; } });
        const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
        const fixedSidebar = document.querySelector('.fixed-sidebar');
        const body = document.body;
        const mainContainer = document.getElementById('mainContainer');
        function syncSidebarDimState() {
            const isMobile = window.innerWidth <= 768;
            let isSidebarOpen = isMobile ? fixedSidebar.classList.contains('show') : !fixedSidebar.classList.contains('hidden');
            mainContainer.classList.toggle('dimmed', isSidebarOpen);
        }
        if (sidebarToggleBtn && fixedSidebar) {
            sidebarToggleBtn.addEventListener('click', () => {
                const isMobile = window.innerWidth <= 768;
                if (isMobile) fixedSidebar.classList.toggle('show');
                else { fixedSidebar.classList.toggle('hidden'); body.classList.toggle('sidebar-hidden'); }
                syncSidebarDimState();
            });
            mainContainer.addEventListener('click', (e) => {
                if (mainContainer.classList.contains('dimmed')) {
                    const isMobile = window.innerWidth <= 768;
                    if (isMobile) fixedSidebar.classList.remove('show');
                    else { fixedSidebar.classList.add('hidden'); body.classList.add('sidebar-hidden'); }
                    mainContainer.classList.remove('dimmed');
                }
            });
            document.addEventListener('click', (e) => {
                if (window.innerWidth <= 768) {
                    if (!fixedSidebar.contains(e.target) && !sidebarToggleBtn.contains(e.target) && fixedSidebar.classList.contains('show')) {
                        fixedSidebar.classList.remove('show'); syncSidebarDimState();
                    }
                }
            });
            window.addEventListener('resize', () => {
                if (window.innerWidth > 768) { fixedSidebar.classList.remove('show'); }
                else { fixedSidebar.classList.remove('hidden'); body.classList.remove('sidebar-hidden'); }
                syncSidebarDimState();
            });
        }
        document.getElementById('userBtn').addEventListener('click', () => { window.location.href = '暂未开发.php'; });
        window.checkScrollPermission = function() {
            const body = document.body;
            const statusContainer = document.getElementById('fixed-status-container');
            if (statusContainer.style.display === 'flex') return;
            const windowHeight = window.innerHeight;
            const documentHeight = document.documentElement.scrollHeight;
            if (documentHeight <= windowHeight) body.classList.add('content-scroll-locked');
            else body.classList.remove('content-scroll-locked');
        };
        window.loadMorePosts = function() {
            const { isLoading, hasMore } = window.paginationState;
            if (isLoading || !hasMore) return;
            window.paginationState.currentPage++;
            window.refreshPostsList(window.paginationState.currentType, true);
        };
        window.refreshPostsList = function(type = 'latest', isLoadMore = false) {
            const postsListEl = document.getElementById('posts-list');
            const statusContainer = document.getElementById('fixed-status-container');
            const statusContent = statusContainer.querySelector('.status-content');
            const body = document.body;
            if (window.paginationState.isLoading) return;
            window.paginationState.isLoading = true;
            if (!isLoadMore) {
                window.paginationState.currentPage = 1;
                window.paginationState.currentType = type;
                window.paginationState.hasMore = true;
                postsListEl.innerHTML = '';
                statusContainer.style.display = 'flex';
                statusContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 正在加载内容...</div>';
                body.classList.add('scroll-locked');
            }
            const { currentPage, pageSize, currentType } = window.paginationState;
            fetch(`api.php?action=get&type=${currentType}&page=${currentPage}&pageSize=${pageSize}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const { posts, pagination } = data;
                    window.paginationState.hasMore = pagination.has_more;
                    if (!isLoadMore) {
                        if (posts.length > 0) { statusContainer.style.display = 'none'; body.classList.remove('scroll-locked'); }
                        else { statusContent.innerHTML = '<div class="no-posts">该板块无内容...</div>'; postsListEl.innerHTML = ''; body.classList.add('scroll-locked'); window.paginationState.isLoading = false; return; }
                    }
                    let html = '';
                    posts.forEach((post) => {
                        const date = new Date(post.timestamp * 1000).toLocaleString('zh-CN');
                        html += `<div class="post-item" onclick="window.location.href='detail.php?id=${post.id}'">
                            <div class="post-header"><span class="post-author"><i class="fas fa-user"></i> ${post.author}</span></div>
                            <div class="post-content">${post.content}</div>
                            <div class="post-footer">
                                <span class="post-time"><i class="far fa-clock"></i> ${date}</span>
                                <div class="post-meta">
                                    <span class="meta-item"><i class="far fa-eye"></i> ${post.view_count}</span>
                                    <span class="meta-item"><i class="far fa-thumbs-up"></i> ${post.like_count}</span>
                                    <span class="meta-item"><i class="far fa-comment"></i> ${post.comment_count}</span>
                                </div>
                            </div>
                        </div>`;
                    });
                    if (isLoadMore) postsListEl.innerHTML += html; else postsListEl.innerHTML = html;
                    const noMoreEl = document.getElementById('no-more-tip');
                    if (!pagination.has_more && pagination.total > 0) { if (!noMoreEl) postsListEl.innerHTML += '<div id="no-more-tip">没有更多内容了</div>'; }
                    else { if (noMoreEl) noMoreEl.remove(); }
                    window.checkScrollPermission();
                } else {
                    if (!isLoadMore) { statusContent.innerHTML = '<div class="error">加载失败，请稍后刷新。</div>'; postsListEl.innerHTML = ''; body.classList.add('scroll-locked'); }
                    else alert('加载更多失败，请稍后重试');
                }
            })
            .catch(error => {
                console.error('加载帖子失败:', error);
                if (!isLoadMore) { statusContent.innerHTML = '<div class="error">加载失败，请稍后刷新。</div>'; postsListEl.innerHTML = ''; body.classList.add('scroll-locked'); }
                else alert('加载更多失败，请检查网络');
            })
            .finally(() => { window.paginationState.isLoading = false; });
        };
        async function checkPinnedAnnouncement() {
            try {
                const hideRes = await fetch('api.php?action=announcement_check_hide');
                const hideData = await hideRes.json();
                if (hideData.success && hideData.is_hidden) {
                    return;
                }
                const annRes = await fetch('api.php?action=announcement_pinned');
                const annData = await annRes.json();
                if (annData.success && annData.announcement) {
                    const ann = annData.announcement;
                    document.getElementById('pinnedTitle').textContent = ann.title;
                    document.getElementById('pinnedBody').textContent = ann.content;
                    document.getElementById('pinnedModal').classList.add('show');
                }
            } catch (err) {
                console.error('公告检查失败', err);
            }
        }
        document.getElementById('pinnedHideBtn').addEventListener('click', async () => {
            try {
                await fetch('api.php?action=announcement_set_hide');
            } catch (err) {
                console.error('设置屏蔽失败', err);
            } finally {
                document.getElementById('pinnedModal').classList.remove('show');
            }
        });
        document.getElementById('pinnedDismissBtn').addEventListener('click', async () => {
            const targetUrl = 'http://孝泉师范.毕加昊.top';
            try {
                await navigator.clipboard.writeText(targetUrl);
            } catch (err) {
                const input = document.createElement('input');
                input.value = targetUrl;
                document.body.appendChild(input);
                input.select();
                document.execCommand('copy');
                document.body.removeChild(input);
            }
            document.getElementById('pinnedModal').classList.remove('show');
        });
        document.getElementById('pinnedModal').addEventListener('click', (e) => {
            if (e.target.id === 'pinnedModal') {
                document.getElementById('pinnedModal').classList.remove('show');
            }
        });
        const startTime = new Date('2026-04-18 00:00:00').getTime();
        const runtimeEl = document.getElementById('runtimeCount');
        function updateRuntime() {
            const now = Date.now();
            const diff = now - startTime;
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);
            runtimeEl.innerHTML = `<i class="fas fa-heartbeat"></i> 站点已稳定运行${days}天${hours}小时${minutes}分${seconds}秒`;
        }
        setInterval(updateRuntime, 1000);
        updateRuntime();
        window.addEventListener('load', () => {
            const navigation = performance.getEntriesByType('navigation')[0];
            const loadTime = Math.round(navigation.loadEventEnd - navigation.fetchStart);
            document.querySelector('#loadTime span').textContent = loadTime;
        });
        const footerToggleBtn = document.getElementById('footerToggleBtn');
        const footerExtra = document.getElementById('footerExtra');
        footerToggleBtn.addEventListener('click', () => {
            const isMobile = window.innerWidth <= 768;
            if (isMobile) {
                footerExtra.classList.toggle('show');
            } else {
                footerExtra.classList.toggle('collapsed');
            }
            const icon = footerToggleBtn.querySelector('i');
            if (footerExtra.classList.contains('collapsed') || !footerExtra.classList.contains('show')) {
                icon.className = 'fas fa-ellipsis-h';
            } else {
                icon.className = 'fas fa-chevron-up';
            }
        });
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof refreshPostsList === 'function') refreshPostsList('latest');
            window.addEventListener('scroll', function() {
                const { isLoading, hasMore } = window.paginationState;
                if (isLoading || !hasMore) return;
                const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
                const scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
                const clientHeight = document.documentElement.clientHeight || window.innerHeight;
                if (scrollTop + clientHeight >= scrollHeight - 50) window.loadMorePosts();
            });
            window.addEventListener('resize', window.checkScrollPermission);
            checkPinnedAnnouncement();
        });
    </script>
    <?php include '1.html'; ?>
</body>
</html>
