<?php
header("X-Frame-Options: DENY");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; font-src 'self' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; img-src 'self' data:; connect-src 'self';");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>条款与政策 - 孝泉师范学校学生社区</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @font-face {
            font-family: 'NaiLaoTi';
            src: url('https://cdn.jsdelivr.net/gh/kyomukyomupurin/fonts@main/nailaoti.woff2') format('woff2');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
            ascent-override: 100%;
            descent-override: 20%;
            line-gap-override: 10%;
        }
        :root {
            --bg-gradient-start: #f3f0ff;
            --bg-gradient-end: #e9e3f8;
            --text-primary: #2d2d2d;
            --text-secondary: #595959;
            --accent: #5a189a;
            --accent-light: rgba(90, 24, 154, 0.1);
            --accent-hover: #48127a;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow-color: rgba(90, 24, 154, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
            --scrollbar-thumb: rgba(90, 24, 154, 0.2);
            --scrollbar-track: transparent;
        }
        [data-theme="dark"] {
            --bg-gradient-start: #1a1a2e;
            --bg-gradient-end: #16213e;
            --text-primary: #f0f0f0;
            --text-secondary: #b8b8b8;
            --accent: #bb86fc;
            --accent-light: rgba(187, 134, 252, 0.15);
            --accent-hover: #9955ff;
            --glass-bg: rgba(30, 30, 60, 0.85);
            --glass-border: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(0, 0, 0, 0.3);
            --card-bg: rgba(30, 30, 60, 0.6);
            --scrollbar-thumb: rgba(187, 134, 252, 0.25);
        }
        [data-theme="mint"] {
            --bg-gradient-start: #e8f5e9;
            --bg-gradient-end: #c8e6c9;
            --text-primary: #1b5e20;
            --text-secondary: #388e3c;
            --accent: #2e7d32;
            --accent-light: rgba(46, 125, 50, 0.1);
            --accent-hover: #1b5e20;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.4);
            --shadow-color: rgba(46, 125, 50, 0.08);
            --card-bg: rgba(255, 255, 255, 0.6);
            --scrollbar-thumb: rgba(46, 125, 50, 0.2);
        }
        * {
            -webkit-tap-highlight-color: transparent;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html, body {
            width: 100%;
            min-height: 100vh;
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            background-attachment: fixed;
            color: var(--text-primary);
            font-family: 'NaiLaoTi', 'Segoe UI', 'Microsoft YaHei', 'PingFang SC', sans-serif;
            line-height: 1.5;
        }
        .full-page-container {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            position: relative;
        }
        .top-nav {
            width: 100%;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px) saturate(180%);
            flex-shrink: 0;
            z-index: 10;
            border-bottom: 1px solid var(--glass-border);
        }
        .back-btn {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            background: var(--accent-light);
            border: none;
            color: var(--accent);
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            flex-shrink: 0;
        }
        .back-btn:hover, .back-btn:focus-visible {
            background: var(--accent);
            color: white;
            outline: 2px solid var(--accent);
            outline-offset: 2px;
        }
        .nav-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-primary);
            text-align: center;
            word-break: keep-all;
        }
        .nav-placeholder {
            width: 38px;
            flex-shrink: 0;
        }
        .main-content {
            flex: 1;
            width: 100%;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        .collapse-wrapper {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            gap: 2px;
            overflow-y: auto;
            padding: 12px 0;
            scroll-behavior: smooth;
        }
        .collapse-wrapper::-webkit-scrollbar {
            width: 4px;
        }
        .collapse-wrapper::-webkit-scrollbar-thumb {
            background: var(--scrollbar-thumb);
            border-radius: 4px;
        }
        .collapse-wrapper::-webkit-scrollbar-track {
            background: var(--scrollbar-track);
        }
        .collapse-item {
            width: 94%;
            margin: 0 auto;
            background: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            flex-shrink: 0;
            backdrop-filter: blur(6px);
            border: 1px solid var(--glass-border);
        }
        .collapse-header {
            width: 100%;
            padding: 18px 25px;
            background: var(--glass-bg);
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            user-select: none;
        }
        .collapse-header:hover, .collapse-header:focus-visible {
            background: var(--accent-light);
            outline: none;
        }
        .collapse-title {
            font-size: 1.05rem;
            font-weight: 600;
            color: var(--accent);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .collapse-icon {
            color: var(--accent);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            flex-shrink: 0;
        }
        .collapse-item.active .collapse-icon {
            transform: rotate(180deg);
        }
        .collapse-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            background: var(--card-bg);
        }
        .content-inner {
            padding: 20px 25px;
            line-height: 1.8;
            color: var(--text-primary);
            font-size: 0.95rem;
        }
        .content-inner h4 {
            color: var(--accent);
            margin: 16px 0 8px 0;
            font-size: 1rem;
            font-weight: 600;
        }
        .content-inner p {
            margin-bottom: 12px;
            color: var(--text-secondary);
            text-align: justify;
        }
        .content-inner p:last-child {
            margin-bottom: 0;
        }
        .content-inner ul {
            margin: 8px 0 12px 20px;
        }
        .content-inner li {
            margin-bottom: 8px;
            color: var(--text-secondary);
        }
        .collapse-content::-webkit-scrollbar {
            width: 4px;
        }
        .collapse-content::-webkit-scrollbar-thumb {
            background: var(--scrollbar-thumb);
            border-radius: 2px;
        }
        @media (max-width: 768px) {
            .top-nav {
                height: 55px;
                padding: 0 15px;
            }
            .back-btn, .nav-placeholder {
                width: 34px;
                height: 34px;
                font-size: 16px;
            }
            .nav-title {
                font-size: 1.1rem;
            }
            .collapse-header {
                padding: 15px 20px;
            }
            .collapse-title {
                font-size: 1rem;
            }
            .content-inner {
                padding: 15px 20px;
                font-size: 0.9rem;
            }
            .collapse-wrapper {
                padding: 8px 0;
            }
            .collapse-item {
                width: 92%;
            }
        }
        @media (prefers-reduced-motion: reduce) {
            * {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>
    <div class="full-page-container">
        <nav class="top-nav">
            <button class="back-btn" id="backBtn" aria-label="返回首页">
                <i class="fas fa-arrow-left" aria-hidden="true"></i>
            </button>
            <div class="nav-title">条款与政策</div>
            <div class="nav-placeholder"></div>
        </nav>
        <main class="main-content">
            <div class="collapse-wrapper">
                <div class="collapse-item" id="userAgreementCollapse">
                    <div class="collapse-header" tabindex="0" role="button" aria-expanded="false" aria-controls="userAgreementContent">
                        <div class="collapse-title">
                            <i class="fas fa-file-contract" aria-hidden="true"></i>
                            用户协议
                        </div>
                        <i class="fas fa-chevron-down collapse-icon" aria-hidden="true"></i>
                    </div>
                    <div class="collapse-content" id="userAgreementContent">
                        <div class="content-inner">
                            <h4>一、协议主体与适用范围</h4>
                            <p>1. 本平台为孝泉师范学校在校学生自发搭建的非官方校园交流社区，与孝泉师范学校官方无任何隶属、关联关系，平台所有内容与立场均不代表学校官方。</p>
                            <p>2. 本协议服务对象仅限孝泉师范学校在校学生，校外人员禁止注册、登录及使用本平台任何服务。您使用本平台，即视为您确认自己具备在校学生身份，并同意接受本协议全部条款。</p>
                            <p>3. 本协议是您与平台运营方之间，关于本平台使用相关权利义务的约定，同时适用平台发布的其他专项规则。</p>
                            <h4>二、账号使用规范</h4>
                            <p>1. 您需凭本人真实在校学生相关信息完成注册，保证注册信息真实、准确、完整、有效，禁止冒用、盗用他人信息注册账号。</p>
                            <p>2. 您应对账号的安全与使用行为全权负责，不得将账号出借、出租、转让、售卖给他人使用。如发现账号被盗用或异常使用，应立即联系平台运营方处理。</p>
                            <h4>三、用户行为规范</h4>
                            <p>您在使用本平台过程中，必须严格遵守国家法律法规、学校校规校纪，以及社会公序良俗，不得实施以下行为：</p>
                            <ul>
                                <li>发布、传播违反宪法、法律法规、国家政策的内容；</li>
                                <li>发布、传播谣言、虚假信息，扰乱校园秩序与社会秩序；</li>
                                <li>发布、传播低俗、色情、暴力、恐怖、赌博、教唆犯罪的内容；</li>
                                <li>发布、传播侮辱、诽谤、骚扰、人肉搜索、泄露他人隐私等侵害他人合法权益的内容；</li>
                                <li>发布商业广告、微商推广、刷单返利、诈骗引流等营销或违法违规内容；</li>
                                <li>恶意刷屏、灌水、重复发布无关内容，干扰平台正常运营秩序；</li>
                                <li>实施破解、攻击平台服务器、篡改平台数据等危害网络安全的行为。</li>
                            </ul>
                            <h4>四、知识产权约定</h4>
                            <p>1. 您在本平台发布的原创内容，知识产权归您本人所有，您授予平台非独家、免费、全球范围内的使用权，用于平台展示、传播、优化服务等合法用途。</p>
                            <p>2. 您保证发布的内容不侵犯任何第三方的知识产权、肖像权、名誉权等合法权益，否则由此产生的全部法律责任由您自行承担。</p>
                            <p>3. 平台内的商标、标识、代码、界面设计等知识产权均归平台运营方所有，未经授权，禁止擅自使用、复制、篡改。</p>
                            <h4>五、违规处理</h4>
                            <p>1. 平台有权对您发布的内容进行巡查审核，如发现您违反本协议约定，有权根据违规情节严重程度，采取包括但不限于内容删除、屏蔽、账号限制功能、短期封禁、永久封禁等处理措施。</p>
                            <p>2. 因您的违规行为给平台或第三方造成损失的，您应承担全部赔偿责任；涉嫌违法犯罪的，平台将配合公安机关、学校相关部门进行调查处理。</p>
                            <h4>六、服务的变更与终止</h4>
                            <p>1. 平台有权根据运营需求，对服务内容进行调整、升级、中断或终止，调整前将通过平台公告等方式告知。</p>
                            <p>2. 您有权随时停止使用本平台服务，也可联系运营方申请注销账号。账号注销后，除法律法规另有规定外，平台将清除您的相关个人数据。</p>
                            <h4>七、其他条款</h4>
                            <p>1. 平台有权根据法律法规及运营需求修改本协议，修改后的协议将在平台内公示，公示后即生效。您继续使用本平台，即视为同意修改后的协议。</p>
                            <p>2. 本协议未尽事宜，遵照国家相关法律法规执行。如因本协议产生争议，双方应友好协商解决；协商不成的，任何一方均有权向平台运营方所在地人民法院提起诉讼。</p>
                        </div>
                    </div>
                </div>
                <div class="collapse-item" id="privacyPolicyCollapse">
                    <div class="collapse-header" tabindex="0" role="button" aria-expanded="false" aria-controls="privacyPolicyContent">
                        <div class="collapse-title">
                            <i class="fas fa-user-shield" aria-hidden="true"></i>
                            隐私政策
                        </div>
                        <i class="fas fa-chevron-down collapse-icon" aria-hidden="true"></i>
                    </div>
                    <div class="collapse-content" id="privacyPolicyContent">
                        <div class="content-inner">
                            <p>本隐私政策严格遵照《中华人民共和国个人信息保护法》《中华人民共和国网络安全法》等法律法规制定，我们将严格保护您的个人信息安全，特此向您说明我们如何收集、使用、存储、保护您的个人信息，以及您享有的相关权利。</p>
                            <h4>一、信息收集范围与使用目的</h4>
                            <p>我们遵循「最小必要」原则，仅收集实现平台服务所必需的信息，不会强制收集与服务无关的个人信息：</p>
                            <ul>
                                <li><strong>基础注册信息</strong>：您注册时提供的在校身份相关信息，仅用于身份核验，确保平台仅限本校在校学生使用；</li>
                                <li><strong>发布内容信息</strong>：您主动发布的帖子、评论、图片等内容，用于平台社区交流展示，实现核心服务功能；</li>
                                <li><strong>设备与网络信息</strong>：您的设备型号、操作系统、IP地址、网络日志信息，仅用于平台安全防护、故障排查、优化服务体验；</li>
                                <li><strong>操作行为信息</strong>：您在平台内的点击、浏览、互动记录，仅用于优化平台功能、提升用户体验，不会用于个性化商业广告推送。</li>
                            </ul>
                            <p>我们不会收集您的身份证号、银行卡号、精准地理位置、通讯录、相册等与服务无关的敏感个人信息。</p>
                            <h4>二、信息存储与安全保护</h4>
                            <p>1. 您的个人信息全部存储于中华人民共和国境内，我们不会向境外传输、存储您的个人信息。</p>
                            <p>2. 我们采用行业通用的加密技术、访问控制、防火墙等安全技术措施，保护您的个人信息，防止数据泄露、篡改、丢失。</p>
                            <p>3. 我们严格限制个人信息的访问权限，仅授权必要人员接触相关信息，并签订保密协议，严禁违规泄露、使用用户信息。</p>
                            <p>4. 我们将按照法律法规要求，设置合理的信息留存期限，超出留存期限后，我们将对您的个人信息进行删除或匿名化处理。</p>
                            <h4>三、信息的共享与披露</h4>
                            <p>我们郑重承诺：不会向任何第三方出售、出租、共享、泄露您的个人信息，以下情况除外：</p>
                            <ul>
                                <li>获得您本人明确、主动的授权同意；</li>
                                <li>根据法律法规、司法机关、行政机关的强制性要求必须提供；</li>
                                <li>为维护您的合法权益、社会公共利益所必需的情形。</li>
                            </ul>
                            <p>我们不会委托第三方处理您的个人信息，也不会将您的个人信息用于商业推广、广告营销等用途。</p>
                            <h4>四、您的个人信息权利</h4>
                            <p>您对自己的个人信息享有以下法定权利，我们将在收到您的申请后15个工作日内完成处理：</p>
                            <ul>
                                <li><strong>查阅、复制权</strong>：您有权查阅、复制我们存储的您的个人信息；</li>
                                <li><strong>更正、补充权</strong>：您发现您的个人信息有误、不完整的，有权要求我们更正、补充；</li>
                                <li><strong>删除权</strong>：您有权要求我们删除您发布的内容、账号相关的个人信息；</li>
                                <li><strong>注销权</strong>：您有权随时申请注销账号，账号注销后，我们将按规定清除您的相关个人信息；</li>
                                <li><strong>撤回同意权</strong>：您有权撤回对本隐私政策的同意，撤回后我们将停止收集、使用您的个人信息，但不影响此前基于您同意开展的处理行为。</li>
                            </ul>
                            <h4>五、未成年人保护</h4>
                            <p>我们高度重视未成年人个人信息保护。若您是未成年人，应在监护人的指导、同意下使用本平台，并仔细阅读本隐私政策。我们不会主动收集未成年人的个人信息，如监护人发现我们违规收集了未成年人的个人信息，可立即联系我们，我们将第一时间删除相关信息。</p>
                            <h4>六、政策变更与联系方式</h4>
                            <p>1. 我们有权根据法律法规及运营需求修改本隐私政策，修改后的政策将在平台内公示，公示后即生效。您继续使用本平台，即视为同意修改后的政策。</p>
                            <p>2. 如您对本隐私政策有任何疑问、建议，或需要行使您的个人信息相关权利，可通过平台内的联系方式与我们取得联系。</p>
                        </div>
                    </div>
                </div>
                <div class="collapse-item" id="disclaimerCollapse">
                    <div class="collapse-header" tabindex="0" role="button" aria-expanded="false" aria-controls="disclaimerContent">
                        <div class="collapse-title">
                            <i class="fas fa-exclamation-circle" aria-hidden="true"></i>
                            免责条款
                        </div>
                        <i class="fas fa-chevron-down collapse-icon" aria-hidden="true"></i>
                    </div>
                    <div class="collapse-content" id="disclaimerContent">
                        <div class="content-inner">
                            <p>您在使用本平台前，请仔细阅读本免责条款，您使用本平台的行为，即视为您同意并接受本条款全部内容。</p>
                            <h4>一、平台性质免责</h4>
                            <p>1. 本平台为孝泉师范学校在校学生自发搭建的非官方校园社区，与孝泉师范学校官方无任何隶属、关联、授权关系，平台内所有内容、观点、行为均不代表学校官方立场，学校不对本平台的任何行为与内容承担责任。</p>
                            <p>2. 本平台仅为在校学生提供免费的信息发布、交流互动服务，无任何商业盈利行为，不构成任何形式的服务承诺与担保。</p>
                            <h4>二、内容相关免责</h4>
                            <p>1. 平台内所有用户发布的内容，仅代表发布者个人观点，不代表本平台立场。平台对用户发布内容的真实性、准确性、合法性、完整性不做任何明示或默示的担保，不对内容引发的任何纠纷、损失承担责任。</p>
                            <p>2. 您因信赖平台内用户发布的内容而做出的任何判断、决策、行为，所产生的全部风险与损失由您自行承担。如您发现违规、侵权内容，可联系平台进行举报处理，平台将按规定及时处理。</p>
                            <h4>三、使用行为免责</h4>
                            <p>1. 您应对自己在平台内的所有操作行为、发布内容、互动交流承担全部法律责任。因您的行为给第三方或平台造成损失的，全部责任由您自行承担。</p>
                            <p>2. 平台不对您通过本平台与其他用户产生的交流、交易、线下互动等行为承担任何责任，由此引发的任何纠纷、损失，均由您自行协商解决。</p>
                            <h4>四、服务稳定性免责</h4>
                            <p>1. 对于因服务器维护、设备故障、网络中断、黑客攻击、不可抗力（包括但不限于自然灾害、疫情、政策调整）等原因，导致平台服务中断、无法正常使用、数据丢失的，平台不承担任何赔偿责任，将尽力恢复服务并提前告知维护计划。</p>
                            <p>2. 平台有权根据运营需求调整、中断、终止部分或全部服务，对此不承担任何责任，将提前通过平台公告告知用户。</p>
                            <h4>五、法律责任边界</h4>
                            <p>1. 本条款不免除平台因故意、重大过失造成用户合法权益损害的法定责任，也不排除法律法规的强制性规定。</p>
                            <p>2. 如您不同意本免责条款的任何内容，请您立即停止注册、使用本平台。</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            (function() {
                try {
                    const savedTheme = localStorage.getItem('community_theme');
                    if (savedTheme) {
                        const theme = JSON.parse(savedTheme);
                        if (theme.name === 'custom' && theme.vars) {
                            Object.entries(theme.vars).forEach(([key, value]) => {
                                document.documentElement.style.setProperty(key, value);
                            });
                        } 
                        else if (theme.name && theme.name !== 'light') {
                            document.documentElement.setAttribute('data-theme', theme.name);
                        }
                        else {
                            document.documentElement.removeAttribute('data-theme');
                        }
                    }
                } catch(e) {
                    console.error('主题加载失败', e);
                    document.documentElement.removeAttribute('data-theme');
                }
            })();
            const backBtn = document.getElementById('backBtn');
            backBtn.addEventListener('click', function() {
                if (window.history.length > 1) {
                    window.history.back();
                } else {
                    window.location.href = 'index.php';
                }
            });
            const collapseItems = document.querySelectorAll('.collapse-item');
            let isAnimating = false;
            function toggleCollapse(item) {
                if (isAnimating) return;
                isAnimating = true;
                const isActive = item.classList.contains('active');
                const content = item.querySelector('.collapse-content');
                const header = item.querySelector('.collapse-header');
                collapseItems.forEach(otherItem => {
                    if (otherItem !== item && otherItem.classList.contains('active')) {
                        const otherContent = otherItem.querySelector('.collapse-content');
                        const otherHeader = otherItem.querySelector('.collapse-header');
                        otherItem.classList.remove('active');
                        otherHeader.setAttribute('aria-expanded', 'false');
                        otherContent.style.maxHeight = '0px';
                    }
                });
                if (isActive) {
                    item.classList.remove('active');
                    header.setAttribute('aria-expanded', 'false');
                    content.style.maxHeight = '0px';
                } else {
                    item.classList.add('active');
                    header.setAttribute('aria-expanded', 'true');
                    const contentHeight = content.scrollHeight;
                    content.style.maxHeight = contentHeight + 'px';
                }
                setTimeout(() => {
                    isAnimating = false;
                    if (item.classList.contains('active')) {
                        content.style.maxHeight = content.scrollHeight + 'px';
                    }
                }, 400);
            }
            collapseItems.forEach(item => {
                const header = item.querySelector('.collapse-header');
                header.addEventListener('click', () => toggleCollapse(item));
                header.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        toggleCollapse(item);
                    }
                });
            });
        });
    </script>
</body>
</html>
