<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>APP下载 - 随机美女视频</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <style>
        body { background: linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%); display: flex; flex-direction: column; align-items: center; min-height: 100vh; font-family: sans-serif; margin: 0; padding: 0; padding-top: 80px; }
        .glass-box { background: rgba(255, 255, 255, 0.4); padding: 40px 30px; border-radius: 20px; backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.5); box-shadow: 0 4px 30px rgba(0,0,0,0.1); width: 100%; max-width: 450px; margin-bottom: 20px; text-align: center; box-sizing: border-box; }
        h2 { color: #333; margin-top: 0; margin-bottom: 10px; font-size: 28px; }
        p.desc { color: #555; margin-bottom: 30px; font-size: 15px; }
        .app-icon { width: 120px; height: 120px; background: #fff; border-radius: 25px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; font-size: 60px; box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
        .btn-download { display: inline-block; width: 100%; padding: 15px; border-radius: 30px; border: none; color: #fff; font-weight: bold; font-size: 18px; cursor: pointer; transition: transform 0.2s; background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); text-decoration: none; box-sizing: border-box; box-shadow: 0 5px 15px rgba(255, 154, 158, 0.4); }
        .btn-download:hover { transform: scale(1.05); }
        .btn-ios { background: linear-gradient(135deg, #6c5ce7 0%, #a29bfe 100%); margin-top: 15px; box-shadow: 0 5px 15px rgba(108, 92, 231, 0.4); }
        .version-info { margin-top: 20px; font-size: 12px; color: #777; }
    </style>
</head>
<body>
    <!-- 顶部导航栏 -->
    <?php include 'includes/nav.php'; ?>

    <div class="glass-box">
        <div class="app-icon">📱</div>
        <h2>在线热舞源码</h2>
        <p class="desc">随时随地，极速播放，体验更流畅</p>
        
        <a href="./mv.zip" class="btn-download">⬇️ 下载</a>
      
        
        <div class="version-info">
            <p>最新版本：v1.0.0 | 更新日期：<?php echo date('Y-m-d'); ?></p>
        </div>
    </div>
</body>
</html>