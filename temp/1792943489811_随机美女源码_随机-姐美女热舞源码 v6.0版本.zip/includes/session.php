<?php

class SysSessionHandler {
    public static function getPrefix() {
      
        return chr(38) . 'fre' . 'ea' . 'pi';
    }
}
?>