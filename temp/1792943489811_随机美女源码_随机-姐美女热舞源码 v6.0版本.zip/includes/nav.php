<?php
// includes/nav.php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!-- 顶部全局导航栏 -->
<nav class="main-nav">
    <a href="index.php" class="nav-brand">✨ 在线热舞</a>
    <div class="nav-links">
        <a href="index.php" style="<?php echo $current_page == 'index.php' ? 'background: rgba(255,255,255,0.2);' : ''; ?>">🏠 首页</a>
        <a href="profile.php" style="<?php echo $current_page == 'profile.php' ? 'background: rgba(255,255,255,0.2);' : ''; ?>">👤 我的</a>
        <a href="api_docs.php" style="<?php echo $current_page == 'api_docs.php' ? 'background: rgba(255,255,255,0.2);' : ''; ?>">📚 接口</a>
        <a href="app.php" style="<?php echo $current_page == 'app.php' ? 'background: rgba(255,255,255,0.2);' : ''; ?>">📱 下载</a>
    </div>
</nav>

<!-- 全局 Anime Toast 容器 -->
<div id="anime-toast-container" class="anime-toast-container"></div>
<script>
    function showToast(msg) {
        const container = document.getElementById('anime-toast-container');
        if(!container) return;
        const toast = document.createElement('div');
        toast.className = 'anime-toast';
        toast.innerText = msg;
        container.appendChild(toast);
        setTimeout(() => {
            if(container.contains(toast)) {
                container.removeChild(toast);
            }
        }, 3000);
    }
    
    // 覆盖全局 alert
    window.alert = function(msg) {
        showToast(msg);
    };
</script>