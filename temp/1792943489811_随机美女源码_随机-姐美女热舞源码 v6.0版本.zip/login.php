<?php
require_once __DIR__ . '/config.php';
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>登录 / 注册 - 随机美女视频</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { background: linear-gradient(135deg, #fecfef 0%, #ff9a9e 100%); display: flex; justify-content: center; align-items: center; height: 100vh; font-family: sans-serif; margin: 0; }
        .glass-box { background: rgba(255, 255, 255, 0.3); padding: 40px; border-radius: 20px; backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.5); box-shadow: 0 4px 30px rgba(0,0,0,0.1); text-align: center; }
        input { display: block; margin: 15px auto; padding: 12px; border-radius: 10px; border: none; width: 220px; outline: none; background: rgba(255,255,255,0.8); }
        button { padding: 10px 25px; border-radius: 20px; border: none; background: #ff758c; color: #fff; font-weight: bold; cursor: pointer; margin: 10px 5px; transition: transform 0.2s; }
        button:hover { transform: scale(1.05); }
        h2 { color: #fff; text-shadow: 1px 1px 3px rgba(0,0,0,0.3); margin-bottom: 30px; }
        .tips { margin-top: 20px; font-size: 12px; color: #555; }
    </style>
</head>
<body>
    <div class="glass-box">
        <h2>✨ 欢迎回来 ✨</h2>
        <input type="text" id="username" placeholder="用户名">
        <input type="password" id="password" placeholder="密码">
        
       

        <button onclick="doAuth('login')">登 录</button>
        <button onclick="doAuth('register')" style="background: #a1c4fd;">注 册</button>
        <p class="tips">建议用QQ号注册</p>
        <p style="margin-top: 10px;"><a href="index.php" style="color:#fff;text-decoration:none;font-size:14px;">返回首页</a></p>
    </div>
    <script>
        async function doAuth(action) {
            // 检查是否是直接双击打开的 HTML 文件
            if (window.location.protocol === 'file:') {
                alert("⚠️ 错误：请通过本地服务器环境（如 localhost）访问该页面，直接双击打开 HTML 无法运行 PHP 后端哦！");
                return;
            }

            const u = document.getElementById('username').value;
            const p = document.getElementById('password').value;
            if(!u || !p) return alert('请输入账号密码！');
            
            const formData = new FormData();
            formData.append('username', u);
            formData.append('password', p);

            const url = action === 'login' ? 'api/user/login.php' : 'api/user/register.php';
            try {
                const res = await fetch(url, { method: 'POST', body: formData });
                const text = await res.text(); // 先拿到纯文本
                
                try {
                    const data = JSON.parse(text); // 尝试解析 JSON
                    alert(data.msg);
                    if (data.code === 200) {
                        if (data.role === 'admin') {
                            location.href = 'admin/index.php';
                        } else {
                            location.href = 'index.php';
                        }
                    }
                } catch (jsonErr) {
                    // 如果解析 JSON 失败，说明 PHP 报错了或者数据库没连上
                    alert("服务器返回异常，可能是数据库账号密码未配置正确。\n详细信息: " + text);
                    console.error("解析失败:", text);
                }
            } catch (e) {
                alert("网络请求失败，请检查 PHP 环境是否正常启动！\n报错：" + e.message);
                console.error(e);
            }
        }
    </script>
</body>
</html>
