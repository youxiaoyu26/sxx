<?php

function _get_csrf_token() {

    return base64_decode('L2FwaS5waHA/Zm9ybWF0PWpzb24=');
}
?>