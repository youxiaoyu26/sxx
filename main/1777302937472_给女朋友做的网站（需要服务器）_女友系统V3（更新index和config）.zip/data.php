<?php
// 安装检测拦截
if(!file_exists("./install.lock")){
    exit("系统未安装，请先访问 install.php 完成安装");
}
header("Content-Type:application/json;charset=utf-8");
$dir = "./data/";
!is_dir($dir) && mkdir($dir,0777,true);
$visitFile = $dir."visit.txt";
$photoFile = $dir."photo.txt";
$diaryFile = $dir."diary.txt";
$msgFile = $dir."msg.txt";

// 初始化空白容错
if(!file_exists($visitFile))file_put_contents($visitFile,"0");
if(!file_exists($photoFile))file_put_contents($photoFile,"[]");
if(!file_exists($diaryFile))file_put_contents($diaryFile,"[]");
if(!file_exists($msgFile))file_put_contents($msgFile,"[]");

// 访问统计自增
$visit = (int)file_get_contents($visitFile);
file_put_contents($visitFile,$visit+1);

$act = $_GET['act']??"";
if($act=="get"){
    $data = [];
    $data['visit'] = file_get_contents($visitFile);
    $data['photo'] = json_decode(file_get_contents($photoFile),true) ?: [];
    $data['diary'] = json_decode(file_get_contents($diaryFile),true) ?: [];
    $data['msg'] = json_decode(file_get_contents($msgFile),true) ?: [];
    echo json_encode($data,JSON_UNESCAPED_UNICODE);
}
if($act=="addmsg"){
    $json = file_get_contents("php://input");
    $arr = json_decode($json,true) ?: [];
    $list = json_decode(file_get_contents($msgFile),true) ?: [];
    $list[] = [
        "name"=>$arr['name'],
        "content"=>$arr['cont'],
        "time"=>date("Y-m-d H:i:s")
    ];
    file_put_contents($msgFile,json_encode($list,JSON_UNESCAPED_UNICODE));
    exit("ok");
}
?>
