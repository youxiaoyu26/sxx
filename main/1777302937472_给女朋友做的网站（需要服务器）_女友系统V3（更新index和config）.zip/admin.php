<?php
// 安装检测
if(!file_exists("./install.lock")){
    header("Location:install.php");exit;
}
$dir = "./data/";
!is_dir($dir) && mkdir($dir,0777,true);
$cf = file_get_contents("config.php");
$photoFile = $dir."photo.txt";
$diaryFile = $dir."diary.txt";
$msgFile = $dir."msg.txt";

//保存照片链接
if(isset($_POST['savePhoto'])){
    $text = $_POST['photoText'];
    $lines = explode(PHP_EOL,$text);
    $arr = [];
    foreach($lines as $v){
        $v = trim($v);
        if(!empty($v)) $arr[] = $v;
    }
    file_put_contents($photoFile,json_encode($arr,JSON_UNESCAPED_UNICODE));
    header("Location:admin.php");exit;
}

//新增日记
if(isset($_POST['diary'])){
    $d = json_decode(file_get_contents($diaryFile),true) ?: [];
    $d[] = ["content"=>$_POST['diary'],"time"=>date("Y-m-d H:i:s")];
    file_put_contents($diaryFile,json_encode($d,JSON_UNESCAPED_UNICODE));
    header("Location:admin.php");exit;
}

//删除日记
if(isset($_POST['delDiary'])){
    $id = (int)$_POST['delDiary'];
    $data = json_decode(file_get_contents($diaryFile),true) ?: [];
    array_splice($data,$id,1);
    file_put_contents($diaryFile,json_encode($data,JSON_UNESCAPED_UNICODE));
    header("Location:admin.php");exit;
}

//删除留言
if(isset($_POST['delmsg'])){
    $idx = (int)$_POST['delmsg'];
    $m = json_decode(file_get_contents($msgFile),true) ?: [];
    array_splice($m,$idx,1);
    file_put_contents($msgFile,json_encode($m,JSON_UNESCAPED_UNICODE));
    header("Location:admin.php");exit;
}

//修改配置
if(isset($_POST['editCf'])){
    file_put_contents("config.php",$_POST['cf']);
    header("Location:admin.php");exit;
}

// 空白容错
$photoList = json_decode(file_get_contents($photoFile),true) ?: [];
$diaryList = json_decode(file_get_contents($diaryFile),true) ?: [];
$msgList = json_decode(file_get_contents($msgFile),true) ?: [];
$photoText = implode("\n",$photoList);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>女友系统-全能后台</title>
<style>
body{background:#fef0f5;padding:30px;}
.box{max-width:700px;margin:0 auto;background:#fff;padding:30px;border-radius:20px;margin-bottom:20px;}
textarea,input{width:100%;padding:10px;margin:8px 0;border:1px solid #ffc8d4;border-radius:12px;}
button{background:#ff6b81;color:#fff;border:none;padding:10px 20px;border-radius:50px;cursor:pointer;}
.item{padding:10px;border-bottom:1px solid #eee;}
.del-btn{background:#eee;color:#333;border:none;padding:4px 8px;border-radius:6px;}
</style>
</head>
<body>

<div class="box">
    <h3>💖 基础资料修改</h3>
    <form method="post">
        <textarea name="cf" rows="8"><?php echo $cf;?></textarea>
        <button name="editCf">保存修改</button>
    </form>
</div>

<div class="box">
    <h3>🖼️ 照片墙管理（一行一个链接）</h3>
    <form method="post">
        <textarea name="photoText" rows="8"><?php echo $photoText;?></textarea>
        <button name="savePhoto">保存</button>
    </form>
</div>

<div class="box">
    <h3>📝 发布情侣日记</h3>
    <form method="post">
        <textarea name="diary" rows="4" placeholder="输入日记内容"></textarea>
        <button>发布</button>
    </form>
</div>

<!-- 日记管理 带删除 -->
<div class="box">
    <h3>📒 日记管理</h3>
    <?php foreach($diaryList as $k=>$v):?>
    <div class="item">
        <div><?php echo $v['content'] ?></div>
        <div style="font-size:12px;color:#999;margin:4px 0;"><?php echo $v['time'] ?></div>
        <form method="post" style="display:inline">
            <input type="hidden" name="delDiary" value="<?php echo $k ?>">
            <button class="del-btn">删除</button>
        </form>
    </div>
    <?php endforeach;?>
</div>

<div class="box">
    <h3>💬 留言管理</h3>
    <?php foreach($msgList as $k=>$v):?>
    <div class="item">
        <b><?php echo $v['name'] ?></b>：<?php echo $v['content'] ?>
        <div style="font-size:12px;color:#999;"><?php echo $v['time'] ?></div>
        <form method="post" style="display:inline">
            <input type="hidden" name="delmsg" value="<?php echo $k ?>">
            <button class="del-btn">删除</button>
    </form>
    </div>
    <?php endforeach;?>
</div>

<div class="box">
    <a href="index.html">← 返回首页</a>
</div>

</body>
</html>
