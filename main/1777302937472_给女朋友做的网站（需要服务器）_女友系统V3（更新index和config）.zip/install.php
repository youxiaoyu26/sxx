<?php
// 安装锁文件
$lock = "./install.lock";
if(file_exists($lock)){
    exit("⚠️ 系统已安装，禁止重复安装！<a href='copyright.html'>前往版权页面</a>");
}

// 环境检测
$check = [];
// 检测PHP版本
$check['php'] = version_compare(PHP_VERSION, '7.0.0', '>=');
// 检测目录写入权限
$check['dir'] = is_writable("./");
// 检测data目录可创建
$check['dataDir'] = true;
// 检测文件创建权限
$check['fileWrite'] = is_writable("./");

// 安装逻辑
if(isset($_POST['install'])){
    // 创建data目录
    $dataDir = "./data/";
    !is_dir($dataDir) && mkdir($dataDir,0777,true);
    
    // 初始化空白数据文件
    file_put_contents($dataDir."visit.txt","0");
    file_put_contents($dataDir."photo.txt","[]");
    file_put_contents($dataDir."diary.txt","[]");
    file_put_contents($dataDir."msg.txt","[]");

    // 生成空白config.php
    $emptyConfig = '<?php
header("Content-Type:application/json;charset=utf-8");
$info = [
    "avatar" => "",
    "name" => "",
    "age" => "",
    "birth" => "",
    "hobby" => "",
    "tag" => "",
    "loveTime" => ""
];
echo json_encode($info,JSON_UNESCAPED_UNICODE);
?>';
    file_put_contents("config.php",$emptyConfig);

    // 生成安装锁
    file_put_contents($lock,"已安装");

    // 安装完成 直接跳转到版权页面
    echo "<script>alert('✅ 安装完成，请阅读版权协议！');location.href='copyright.html';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>女友系统 - 安装向导</title>
<style>
body{background:#fef0f5;font-family:微软雅黑;text-align:center;padding:50px;}
.box{background:#fff;max-width:500px;margin:0 auto;padding:30px;border-radius:20px;}
.item{text-align:left;padding:12px 0;border-bottom:1px solid #eee;}
.ok{color:#27ae60;}
.no{color:#e74c3c;}
button{background:#ff6b81;color:#fff;border:none;padding:12px 30px;border-radius:50px;font-size:16px;margin-top:20px;cursor:pointer;}
.tip{color:#999;font-size:14px;margin:15px 0;}
</style>
</head>
<body>
<div class="box">
    <h2>💖 系统安装向导</h2>
    <p class="tip">环境检测通过后即可一键初始化系统</p>

    <div class="item">
        PHP版本 ≥7.0：
        <?php echo $check['php'] ? '<span class="ok">✅ 正常</span>' : '<span class="no">❌ 版本过低</span>'; ?>
    </div>
    <div class="item">
        根目录写入权限：
        <?php echo $check['dir'] ? '<span class="ok">✅ 正常</span>' : '<span class="no">❌ 无写入权限</span>'; ?>
    </div>
    <div class="item">
        文件创建权限：
        <?php echo $check['fileWrite'] ? '<span class="ok">✅ 正常</span>' : '<span class="no">❌ 权限不足</span>'; ?>
    </div>

    <form method="post">
        <button name="install">🚀 一键安装初始化</button>
    </form>
</div>
</body>
</html>
