<?php
header("Content-Type:application/json;charset=utf-8");
$info = [
    "avatar" => "头像，图床https://mgtc.mgznb.cn",
    "name" => "名字",
    "age" => "年龄",
    "birth" => "她的生日",
    "hobby" => "她的喜好",
    "tag" => "称呼",
    "loveTime" => "年-月 如:02-日如:01"
];
echo json_encode($info,JSON_UNESCAPED_UNICODE);
?>
